/* LOGIN ADMINISTRATIVO — modo de demonstração temporário.
   A autenticação real será integrada ao banco posteriormente. */
(() => {
  const $ = (s) => document.querySelector(s);
  const msg = (t) => {
    const el = $("#admin-msg");
    el.textContent = t;
    el.classList.toggle("hidden", !t);
  };
  if (window.lucide) lucide.createIcons();
  $("#admin-pw").addEventListener("click", () => {
    const i = $("#admin-senha");
    i.type = i.type === "password" ? "text" : "password";
  });
  $("#form-admin").addEventListener("submit", (e) => {
    e.preventDefault();
    // Acesso temporário: não exige usuário nem senha nesta etapa do projeto.
    sessionStorage.setItem("admin_demo_mode", "true");
    sessionStorage.setItem("admin_demo_nome", $("#admin-email").value.trim() || "Administrador");
    window.location.href = "admin.html";
  });
})();
