    /* ================================================================
       SENHA
       ================================================================ */

    const senhaForm = () => {

      const p = S.f.n || "";
      const s = forca(p);

      return `
        <form data-form="senha" class="max-w-md space-y-4">

          ${ttl("lock", "Alterar senha")}

          ${input(
        "Senha atual",
        "a",
        {
          type: "password",
          icon: "lock"
        }
      )}

          ${input(
        "Nova senha",
        "n",
        {
          type: "password",
          icon: "lock",
          r: true
        }
      )}

          ${p
          ? `
                <div>

                  <div class="flex gap-1">

                    ${[1, 2, 3, 4]
            .map(
              (i) => `
                          <span
                            class="h-1.5 flex-1 rounded-full ${i <= s
                  ? [
                    "",
                    "bg-rose-400",
                    "bg-yellow-400",
                    "bg-green-400",
                    "bg-green-600"
                  ][s]
                  : "bg-gray-200"
                }"
                          ></span>
                        `
            )
            .join("")}

                  </div>

                  <p class="mt-1 text-xs text-[#6B7280]">
                    Força:
                    ${[
            "Muito fraca",
            "Fraca",
            "Média",
            "Forte",
            "Muito forte"
          ][s]
          }
                  </p>

                </div>
              `
          : ""
        }

          ${input(
          "Confirmar nova senha",
          "c",
          {
            type: "password",
            icon: "lock"
          }
        )}

          ${msgHtml()}

          ${btn("Alterar senha", {
          type: "submit"
        })}

        </form>
      `;
    };
