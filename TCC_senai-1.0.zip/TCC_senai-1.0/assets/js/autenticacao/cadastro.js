    /* ================================================================
       CADASTRO
       ================================================================ */

    const register = () =>
      authShell(
        `
          ${logo}

          <h1 class="text-4xl font-bold leading-tight">
            Juntos por um ambiente de aprendizado ainda melhor!
          </h1>

          <p class="max-w-md text-white/85">
            Cadastre-se para acessar o sistema e gerenciar suas reservas, solicitações e espaços de forma simples e rápida.
          </p>
        `,
        `
          <h2 class="text-2xl font-bold text-[#C8102E]">
            Criar conta
          </h2>

          <p class="mb-5 text-sm text-[#6B7280]">
            Preencha os dados abaixo para acessar o sistema.
          </p>

          <form data-form="cadastro" class="grid gap-3 sm:grid-cols-2">

            <div class="sm:col-span-2">
              ${input(
          "Nome completo",
          "nome",
          {
            icon: "user",
            ph: "Digite seu nome completo"
          }
        )}
            </div>

            <div class="sm:col-span-2">
              ${input(
          "E-mail institucional",
          "email",
          {
            icon: "mail",
            type: "email",
            ph: "exemplo@senai.br"
          }
        )}
            </div>

            ${input("CPF", "cpf", {
          ph: "000.000.000-00"
        })}

            ${input(
          "Data de nascimento",
          "nasc",
          {
            type: "date"
          }
        )}

            ${input("Telefone", "tel", {
          ph: "(00) 00000-0000",
          req: false
        })}

            ${input("Matrícula", "mat")}

            <div class="sm:col-span-2">

              ${select(
          "Tipo de usuário",
          "tipo",
          [
            "Docente",
            "Funcionário",
            "Coordenador",
            "Administrador"
          ],
          {
            ph: "Selecione o seu perfil",
            req: true
          }
        )}

            </div>

            ${input(
          "Senha",
          "senha",
          {
            type: "password",
            icon: "lock",
            ph: "Crie uma senha"
          }
        )}

            ${input(
          "Confirmar senha",
          "conf",
          {
            type: "password",
            icon: "lock",
            ph: "Repita a senha"
          }
        )}

            ${msgHtml()}

            ${btn("Criar conta", {
          type: "submit",
          c: "sm:col-span-2"
        })}

            ${btn("Voltar para o login", {
          a: "go",
          v: "login",
          i: "arrow-left",
          k: "outline",
          c: "sm:col-span-2"
        })}

          </form>
        `
      );
