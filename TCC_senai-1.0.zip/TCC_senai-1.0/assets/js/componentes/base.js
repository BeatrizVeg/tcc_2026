    /* ================================================================
       COMPONENTES
       ================================================================ */

    const btn = (
      t,
      {
        a,
        v = "",
        i,
        k = "primary",
        c = "",
        type = "button",
        dis = false
      } = {}
    ) => {

      const K = {
        primary: "bg-[#C8102E] text-white hover:bg-[#A80D25]",
        navy: "bg-[#1E2A78] text-white hover:bg-[#161f5c]",
        outline: "border border-[#C8102E] text-[#C8102E] hover:bg-red-50",
        danger: "bg-rose-100 text-rose-800 hover:bg-rose-200",
        ghost: "text-[#6B7280] hover:bg-gray-100"
      }[k];

      return `
        <button
          type="${type}"
          ${a ? `data-a="${a}" data-v="${esc(v)}"` : ""}
          ${dis ? "disabled" : ""}
          class="inline-flex items-center justify-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold transition active:scale-[.98] disabled:pointer-events-none disabled:opacity-50 ${K} ${c}"
        >
          ${i ? ic(i) : ""}
          ${t}
        </button>
      `;
    };


    const field = (l, inner) => `
      <label class="block">
        <span class="mb-1 block text-xs font-semibold">${l}</span>
        ${inner}
      </label>
    `;


    const input = (
      l,
      k,
      {
        type = "text",
        icon,
        ph = "",
        req = true,
        dis = false,
        r = false,
        extra = ""
      } = {}
    ) =>
      field(
        l,
        `
          <div class="relative">

            ${icon
          ? `<span class="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-[#C8102E]">${ic(icon)}</span>`
          : ""
        }

            <input
              data-k="${k}"
              ${r ? 'data-r="1"' : ""}
              type="${type}"
              value="${esc(S.f[k])}"
              placeholder="${ph}"
              ${req ? "required" : ""}
              ${dis ? "disabled" : ""}
              ${extra}
              class="${FLD} ${icon ? "pl-9" : ""} ${type === "password" ? "pr-10" : ""
        }"
            >

            ${type === "password"
          ? `
                  <button
                    type="button"
                    data-a="pw"
                    class="absolute right-3 top-1/2 -translate-y-1/2 text-[#6B7280]"
                  >
                    ${ic("eye")}
                  </button>
                `
          : ""
        }

          </div>
        `
      );


    const select = (
      l,
      k,
      opts,
      { ph = "Selecione", r = false, req = false } = {}
    ) =>
      field(
        l,
        `
          <select
            data-k="${k}"
            ${r ? 'data-r="1"' : ""}
            ${req ? "required" : ""}
            class="${FLD}"
          >

            <option value="">${ph}</option>

            ${opts
          .map(
            (o) =>
              `<option value="${esc(o)}" ${S.f[k] === o ? "selected" : ""
              }>${esc(o)}</option>`
          )
          .join("")}

          </select>
        `
      );


    const badge = (s) =>
      `<span class="whitespace-nowrap rounded-full px-2.5 py-0.5 text-xs font-semibold ${STATUS[s] || "bg-gray-100 text-gray-700"
      }">${esc(s)}</span>`;


    const empty = (
      icon,
      t,
      p,
      action = ""
    ) => `
      <div class="flex flex-col items-center px-6 py-12 text-center">

        <div class="mb-3 rounded-2xl bg-red-50 p-4 text-[#C8102E]">
          ${ic(icon, "w-7 h-7")}
        </div>

        <p class="font-bold">${t}</p>

        <p class="mt-1 max-w-sm text-sm text-[#6B7280]">
          ${p}
        </p>

        ${action
        ? `<div class="mt-4">${action}</div>`
        : ""
      }

      </div>
    `;


    const stat = (icon, l, v, h, goTo) => `
      <button
        type="button"
        ${goTo ? `data-a="go" data-v="${goTo}"` : ""}
        class="${CARD} p-4 text-left transition hover:-translate-y-0.5 hover:shadow-md"
      >

        <span class="inline-flex rounded-xl bg-red-50 p-2 text-[#C8102E]">
          ${ic(icon, "w-[18px] h-[18px]")}
        </span>

        <p class="mt-3 text-sm font-semibold">${l}</p>
        <p class="text-2xl font-bold text-[#1E2A78]">${v ?? "--"}</p>
        <p class="text-xs text-[#6B7280]">${h || ""}</p>

      </button>
    `;


    const avatar = (name, s = 40, photo = "") => `
      <div
        style="width:${s}px;height:${s}px"
        class="flex shrink-0 items-center justify-center overflow-hidden rounded-full bg-[#1E2A78] text-sm font-semibold text-white"
      >
        ${photo
        ? `<img src="${esc(photo)}" alt="Foto de perfil" class="h-full w-full object-cover" />`
        : name
          ? esc(
            name
              .split(" ")
              .map((n) => n[0])
              .slice(0, 2)
              .join("")
              .toUpperCase()
          )
          : ic("user", "w-1/2 h-1/2")
      }
      </div>
    `;


    const avatarEditavel = (name, s, photo) => `
      <div class="relative">

        ${avatar(name, s, photo)}

        <label
          class="absolute -bottom-1 -right-1 flex h-8 w-8 cursor-pointer items-center justify-center rounded-full border-2 border-white bg-[#C8102E] text-white shadow-sm transition hover:bg-[#A80D25]"
          title="Trocar foto de perfil"
        >
          ${ic("camera", "w-4 h-4")}
          <input type="file" accept="image/*" data-foto-input class="hidden" />
        </label>

      </div>
    `;


    const ttl = (i, t, extra = "") => `
      <div class="flex items-center justify-between">

        <h2 class="flex items-center gap-2 font-bold text-[#A80D25]">
          ${ic(i, "w-[18px] h-[18px]")}
          ${t}
        </h2>

        ${extra}

      </div>
    `;


    const pg = (h) =>
      `<div class="space-y-6 px-4 pb-10 lg:px-8">${h}</div>`;


    const back = (to) => `
      <button
        type="button"
        data-a="go"
        data-v="${to}"
        class="flex items-center gap-1 text-sm font-semibold text-[#1E2A78] hover:underline"
      >
        ${ic("arrow-left")}
        Voltar
      </button>
    `;


    const step = (n, t) => `
      <h2 class="mb-4 flex items-center gap-2 font-bold">

        <span class="flex h-6 w-6 items-center justify-center rounded-full bg-[#C8102E] text-xs text-white">
          ${n}
        </span>

        ${t}

      </h2>
    `;


    const msgHtml = () =>
      S.ui.msg
        ? `
          <p class="text-sm sm:col-span-2 ${S.ui.msg[0] === "err"
          ? "text-rose-700"
          : "text-green-700"
        }">
            ${S.ui.msg[1]}
          </p>
        `
        : "";


    const logo = `
      <img src="${(IN_PAGES ? "../" : "") + "assets/imagens/senai-logo.png"}" alt="SENAI" width="180" height="46" class="h-auto w-44 rounded-md ring-2 ring-white/60">
    `;
