    /* ================================================================
       HELPERS
       ================================================================ */

    const $ = (s) => document.querySelector(s);

    const esc = (s) =>
      String(s ?? "").replace(
        /[&<>"']/g,
        (c) => ({
          "&": "&amp;",
          "<": "&lt;",
          ">": "&gt;",
          '"': "&quot;",
          "'": "&#39;"
        })[c]
      );

    const ic = (n, c = "w-4 h-4") =>
      `<i data-lucide="${n}" class="${c}"></i>`;

    const CARD =
      "bg-white rounded-2xl border border-[#E5E7EB] shadow-sm";

    const FLD =
      "w-full rounded-xl border border-[#E5E7EB] bg-white px-3 py-2.5 text-sm placeholder:text-[#9CA3AF] transition focus:outline-none focus:border-[#C8102E] focus:ring-2 focus:ring-[#C8102E]/20 disabled:bg-[#F8F9FA] disabled:text-[#9CA3AF]";

    const BLOCOS = ["A", "B", "C"];

    const TIPOS = [
      "Salas de aula",
      "Laboratórios",
      "Espaços de convivência",
      "Auditório",
      "Outros"
    ];

    const MESES = [
      "JAN",
      "FEV",
      "MAR",
      "ABR",
      "MAI",
      "JUN",
      "JUL",
      "AGO",
      "SET",
      "OUT",
      "NOV",
      "DEZ"
    ];

    const MESES_COMPLETOS = [
      "Janeiro",
      "Fevereiro",
      "Março",
      "Abril",
      "Maio",
      "Junho",
      "Julho",
      "Agosto",
      "Setembro",
      "Outubro",
      "Novembro",
      "Dezembro"
    ];

    const STATUS = {
      Disponível: "bg-green-100 text-green-800",
      Aprovada: "bg-green-100 text-green-800",
      Confirmada: "bg-green-100 text-green-800",
      "Em análise": "bg-yellow-100 text-yellow-800",
      Ocupado: "bg-rose-100 text-rose-800",
      Recusada: "bg-rose-100 text-rose-800",
      Cancelada: "bg-rose-100 text-rose-800"
    };

    const EQUIP = {
      "Wi-Fi": "wifi",
      Projetor: "projector",
      Computadores: "monitor",
      Ventiladores: "fan",
      "Ar-condicionado": "snowflake",
      Tomadas: "plug",
      "Quadro branco": "presentation"
    };

    const TITULOS = {
      home: "Início",
      reservations: "Minhas Reservas",
      reservation: "Detalhes da Reserva",
      rooms: "Salas e Espaços",
      room: "Detalhes do Espaço",
      new: "Nova Reserva",
      requests: "Solicitações",
      profile: "Meu Perfil",
      notifications: "Notificações"
    };

    const NAV = [
      ["home", "Início", "home"],
      ["reservations", "Minhas Reservas", "clock"],
      ["rooms", "Salas e Espaços", "building-2"],
      ["requests", "Solicitações", "clipboard-list"],
      ["profile", "Meu Perfil", "user"]
    ];

    const CAMPOS = [
      ["nome", "Nome completo"],
      ["cpf", "CPF"],
      ["email", "E-mail institucional"],
      ["nascimento", "Data de nascimento"],
      ["telefone", "Telefone"],
      ["matricula", "Matrícula"],
      ["cargo", "Cargo"]
    ];

    const forca = (p) =>
      [
        p.length >= 8,
        /[A-Z]/.test(p),
        /\d/.test(p),
        /[^A-Za-z0-9]/.test(p)
      ].filter(Boolean).length;
