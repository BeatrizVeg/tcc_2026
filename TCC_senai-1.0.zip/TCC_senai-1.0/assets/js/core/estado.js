    /* ================================================================
       ESTADO
       ================================================================ */

    const now = new Date();

    const S = {
      page: "login",
      menu: false,
      user: null,

      rooms: [],
      reservations: [],
      requests: [],
      notifications: [],

      sel: {},
      ui: {},
      f: {},

      cal: {
        y: now.getFullYear(),
        m: now.getMonth()
      }
    };
