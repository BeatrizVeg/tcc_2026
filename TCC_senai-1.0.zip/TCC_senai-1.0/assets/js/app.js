

    /* ================================================================
       BACK-END
       ================================================================ */

    const BASE = "";

    /* ================================================================
       ROTAS (um arquivo HTML por tela)
       index.html fica na raiz; as demais telas ficam em pages/
       ================================================================ */

    // true quando a página atual está dentro de /pages (script carregado via ../assets/...)
    const IN_PAGES = (
      (document.currentScript && document.currentScript.getAttribute("src")) || ""
    ).startsWith("../");

    const ROUTES = {
      login: "index.html",
      register: "cadastro.html",
      home: "home.html",
      reservations: "minhas_reservas.html",
      reservation: "detalhes_reserva.html",
      rooms: "salas.html",
      room: "detalhes_sala.html",
      new: "nova_reserva.html",
      requests: "solicitacoes.html",
      profile: "perfil.html",
      notifications: "notificacoes.html",
      adminLogin: "admin_login.html"
    };

    // Caminho correto de uma tela a partir da página atual
    const href = (p) => {
      if (p === "login") return IN_PAGES ? "../index.html" : "index.html";
      const file = ROUTES[p] || ROUTES.home;
      return (IN_PAGES ? "" : "pages/") + file;
    };

    const api = {
      usuarios: async () => [],
      perfil: async () => null,
      salas: async () => [],
      reservas: async () => [],
      solicitacoes: async () => [],
      notificacoes: async () => []
    };


    /* ================================================================
       ESTADO
       ================================================================ */

    const now = new Date();

    const S = {
      page: "login",
      menu: false,
      user: null,

      rooms: [],
      reservations: [],
      requests: [],
      notifications: [],

      sel: {},
      ui: {},
      f: {},

      cal: {
        y: now.getFullYear(),
        m: now.getMonth()
      }
    };


    /* ================================================================
       HELPERS
       ================================================================ */

    const $ = (s) => document.querySelector(s);

    const esc = (s) =>
      String(s ?? "").replace(
        /[&<>"']/g,
        (c) => ({
          "&": "&amp;",
          "<": "&lt;",
          ">": "&gt;",
          '"': "&quot;",
          "'": "&#39;"
        })[c]
      );

    const ic = (n, c = "w-4 h-4") =>
      `<i data-lucide="${n}" class="${c}"></i>`;

    const CARD =
      "bg-white rounded-2xl border border-[#E5E7EB] shadow-sm";

    const FLD =
      "w-full rounded-xl border border-[#E5E7EB] bg-white px-3 py-2.5 text-sm placeholder:text-[#9CA3AF] transition focus:outline-none focus:border-[#C8102E] focus:ring-2 focus:ring-[#C8102E]/20 disabled:bg-[#F8F9FA] disabled:text-[#9CA3AF]";

    const BLOCOS = ["A", "B", "C"];

    const TIPOS = [
      "Salas de aula",
      "Laboratórios",
      "Espaços de convivência",
      "Auditório",
      "Outros"
    ];

    const MESES = [
      "JAN",
      "FEV",
      "MAR",
      "ABR",
      "MAI",
      "JUN",
      "JUL",
      "AGO",
      "SET",
      "OUT",
      "NOV",
      "DEZ"
    ];

    const MESES_COMPLETOS = [
      "Janeiro",
      "Fevereiro",
      "Março",
      "Abril",
      "Maio",
      "Junho",
      "Julho",
      "Agosto",
      "Setembro",
      "Outubro",
      "Novembro",
      "Dezembro"
    ];

    const STATUS = {
      Disponível: "bg-green-100 text-green-800",
      Aprovada: "bg-green-100 text-green-800",
      Confirmada: "bg-green-100 text-green-800",
      "Em análise": "bg-yellow-100 text-yellow-800",
      Ocupado: "bg-rose-100 text-rose-800",
      Recusada: "bg-rose-100 text-rose-800",
      Cancelada: "bg-rose-100 text-rose-800"
    };

    const EQUIP = {
      "Wi-Fi": "wifi",
      Projetor: "projector",
      Computadores: "monitor",
      Ventiladores: "fan",
      "Ar-condicionado": "snowflake",
      Tomadas: "plug",
      "Quadro branco": "presentation"
    };

    const TITULOS = {
      home: "Início",
      reservations: "Minhas Reservas",
      reservation: "Detalhes da Reserva",
      rooms: "Salas e Espaços",
      room: "Detalhes do Espaço",
      new: "Nova Reserva",
      requests: "Solicitações",
      profile: "Meu Perfil",
      notifications: "Notificações"
    };

    const NAV = [
      ["home", "Início", "home"],
      ["reservations", "Minhas Reservas", "clock"],
      ["rooms", "Salas e Espaços", "building-2"],
      ["requests", "Solicitações", "clipboard-list"],
      ["profile", "Meu Perfil", "user"]
    ];

    const CAMPOS = [
      ["nome", "Nome completo"],
      ["cpf", "CPF"],
      ["email", "E-mail institucional"],
      ["nascimento", "Data de nascimento"],
      ["telefone", "Telefone"],
      ["matricula", "Matrícula"],
      ["cargo", "Cargo"]
    ];

    const forca = (p) =>
      [
        p.length >= 8,
        /[A-Z]/.test(p),
        /\d/.test(p),
        /[^A-Za-z0-9]/.test(p)
      ].filter(Boolean).length;


    /* ================================================================
       COMPONENTES
       ================================================================ */

    const btn = (
      t,
      {
        a,
        v = "",
        i,
        k = "primary",
        c = "",
        type = "button",
        dis = false
      } = {}
    ) => {

      const K = {
        primary: "bg-[#C8102E] text-white hover:bg-[#A80D25]",
        navy: "bg-[#1E2A78] text-white hover:bg-[#161f5c]",
        outline: "border border-[#C8102E] text-[#C8102E] hover:bg-red-50",
        danger: "bg-rose-100 text-rose-800 hover:bg-rose-200",
        ghost: "text-[#6B7280] hover:bg-gray-100"
      }[k];

      return `
        <button
          type="${type}"
          ${a ? `data-a="${a}" data-v="${esc(v)}"` : ""}
          ${dis ? "disabled" : ""}
          class="inline-flex items-center justify-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold transition active:scale-[.98] disabled:pointer-events-none disabled:opacity-50 ${K} ${c}"
        >
          ${i ? ic(i) : ""}
          ${t}
        </button>
      `;
    };


    const field = (l, inner) => `
      <label class="block">
        <span class="mb-1 block text-xs font-semibold">${l}</span>
        ${inner}
      </label>
    `;


    const input = (
      l,
      k,
      {
        type = "text",
        icon,
        ph = "",
        req = true,
        dis = false,
        r = false,
        extra = ""
      } = {}
    ) =>
      field(
        l,
        `
          <div class="relative">

            ${icon
          ? `<span class="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-[#C8102E]">${ic(icon)}</span>`
          : ""
        }

            <input
              data-k="${k}"
              ${r ? 'data-r="1"' : ""}
              type="${type}"
              value="${esc(S.f[k])}"
              placeholder="${ph}"
              ${req ? "required" : ""}
              ${dis ? "disabled" : ""}
              ${extra}
              class="${FLD} ${icon ? "pl-9" : ""} ${type === "password" ? "pr-10" : ""
        }"
            >

            ${type === "password"
          ? `
                  <button
                    type="button"
                    data-a="pw"
                    class="absolute right-3 top-1/2 -translate-y-1/2 text-[#6B7280]"
                  >
                    ${ic("eye")}
                  </button>
                `
          : ""
        }

          </div>
        `
      );


    const select = (
      l,
      k,
      opts,
      { ph = "Selecione", r = false, req = false } = {}
    ) =>
      field(
        l,
        `
          <select
            data-k="${k}"
            ${r ? 'data-r="1"' : ""}
            ${req ? "required" : ""}
            class="${FLD}"
          >

            <option value="">${ph}</option>

            ${opts
          .map(
            (o) =>
              `<option value="${esc(o)}" ${S.f[k] === o ? "selected" : ""
              }>${esc(o)}</option>`
          )
          .join("")}

          </select>
        `
      );


    const badge = (s) =>
      `<span class="whitespace-nowrap rounded-full px-2.5 py-0.5 text-xs font-semibold ${STATUS[s] || "bg-gray-100 text-gray-700"
      }">${esc(s)}</span>`;


    const empty = (
      icon,
      t,
      p,
      action = ""
    ) => `
      <div class="flex flex-col items-center px-6 py-12 text-center">

        <div class="mb-3 rounded-2xl bg-red-50 p-4 text-[#C8102E]">
          ${ic(icon, "w-7 h-7")}
        </div>

        <p class="font-bold">${t}</p>

        <p class="mt-1 max-w-sm text-sm text-[#6B7280]">
          ${p}
        </p>

        ${action
        ? `<div class="mt-4">${action}</div>`
        : ""
      }

      </div>
    `;


    const stat = (icon, l, v, h, goTo) => `
      <button
        type="button"
        ${goTo ? `data-a="go" data-v="${goTo}"` : ""}
        class="${CARD} p-4 text-left transition hover:-translate-y-0.5 hover:shadow-md"
      >

        <span class="inline-flex rounded-xl bg-red-50 p-2 text-[#C8102E]">
          ${ic(icon, "w-[18px] h-[18px]")}
        </span>

        <p class="mt-3 text-sm font-semibold">${l}</p>
        <p class="text-2xl font-bold text-[#1E2A78]">${v ?? "--"}</p>
        <p class="text-xs text-[#6B7280]">${h || ""}</p>

      </button>
    `;


    const avatar = (name, s = 40, photo = "") => `
      <div
        style="width:${s}px;height:${s}px"
        class="flex shrink-0 items-center justify-center overflow-hidden rounded-full bg-[#1E2A78] text-sm font-semibold text-white"
      >
        ${photo
        ? `<img src="${esc(photo)}" alt="Foto de perfil" class="h-full w-full object-cover" />`
        : name
          ? esc(
            name
              .split(" ")
              .map((n) => n[0])
              .slice(0, 2)
              .join("")
              .toUpperCase()
          )
          : ic("user", "w-1/2 h-1/2")
      }
      </div>
    `;


    const avatarEditavel = (name, s, photo) => `
      <div class="relative">

        ${avatar(name, s, photo)}

        <label
          class="absolute -bottom-1 -right-1 flex h-8 w-8 cursor-pointer items-center justify-center rounded-full border-2 border-white bg-[#C8102E] text-white shadow-sm transition hover:bg-[#A80D25]"
          title="Trocar foto de perfil"
        >
          ${ic("camera", "w-4 h-4")}
          <input type="file" accept="image/*" data-foto-input class="hidden" />
        </label>

      </div>
    `;


    const ttl = (i, t, extra = "") => `
      <div class="flex items-center justify-between">

        <h2 class="flex items-center gap-2 font-bold text-[#A80D25]">
          ${ic(i, "w-[18px] h-[18px]")}
          ${t}
        </h2>

        ${extra}

      </div>
    `;


    const pg = (h) =>
      `<div class="space-y-6 px-4 pb-10 lg:px-8">${h}</div>`;


    const back = (to) => `
      <button
        type="button"
        data-a="go"
        data-v="${to}"
        class="flex items-center gap-1 text-sm font-semibold text-[#1E2A78] hover:underline"
      >
        ${ic("arrow-left")}
        Voltar
      </button>
    `;


    const step = (n, t) => `
      <h2 class="mb-4 flex items-center gap-2 font-bold">

        <span class="flex h-6 w-6 items-center justify-center rounded-full bg-[#C8102E] text-xs text-white">
          ${n}
        </span>

        ${t}

      </h2>
    `;


    const msgHtml = () =>
      S.ui.msg
        ? `
          <p class="text-sm sm:col-span-2 ${S.ui.msg[0] === "err"
          ? "text-rose-700"
          : "text-green-700"
        }">
            ${S.ui.msg[1]}
          </p>
        `
        : "";


    const logo = `
      <img src="${(IN_PAGES ? "../" : "") + "assets/imagens/senai-logo.png"}" alt="SENAI" width="180" height="46" class="h-auto w-44 rounded-md ring-2 ring-white/60">
    `;


    /* ================================================================
       FOTO DE PERFIL
       ================================================================ */

    const redimensionarImagem = (
      file,
      maxSize = 400,
      quality = 0.85
    ) =>
      new Promise((resolve, reject) => {

        const reader = new FileReader();

        reader.onerror = () =>
          reject(reader.error);

        reader.onload = () => {

          const img = new Image();

          img.onerror = () =>
            reject(
              new Error(
                "Não foi possível ler a imagem."
              )
            );

          img.onload = () => {

            let { width, height } = img;

            if (
              width > height &&
              width > maxSize
            ) {

              height = Math.round(
                height * (maxSize / width)
              );

              width = maxSize;

            } else if (height > maxSize) {

              width = Math.round(
                width * (maxSize / height)
              );

              height = maxSize;
            }

            const canvas =
              document.createElement(
                "canvas"
              );

            canvas.width = width;
            canvas.height = height;

            canvas
              .getContext("2d")
              .drawImage(
                img,
                0,
                0,
                width,
                height
              );

            resolve(
              canvas.toDataURL(
                "image/jpeg",
                quality
              )
            );
          };

          img.src = reader.result;
        };

        reader.readAsDataURL(file);
      });


    /* ================================================================
       CÂMERA
       ================================================================ */

    const cameraFoto = () => `
      <div class="sm:col-span-2 rounded-2xl border border-[#E5E7EB] bg-[#F8F9FA] p-4">

        <div class="mb-3 flex items-center gap-2">
          ${ic("scan-face", "w-5 h-5 text-[#C8102E]")}

          <div>
            <p class="font-bold text-[#A80D25]">
              Foto do professor
            </p>

            <p class="text-xs text-[#6B7280]">
              Tire uma foto do rosto para registrar quem realizou a reserva.
            </p>
          </div>
        </div>

        <div class="flex flex-col items-center gap-3">

          <video
            id="cameraVideo"
            autoplay
            playsinline
            class="hidden w-full max-w-sm rounded-xl bg-black object-cover"
          ></video>

          <canvas id="cameraCanvas" class="hidden"></canvas>

          <img
            id="fotoPreview"
            src="${esc(S.f.fotoProfessor || "")}"
            class="${S.f.fotoProfessor ? "" : "hidden"
      } w-full max-w-sm rounded-xl object-cover"
            alt="Foto do professor"
          >

          <div class="flex flex-wrap justify-center gap-2">

            ${btn("Abrir câmera", {
        a: "abrirCamera",
        i: "camera",
        k: "outline"
      })}

            ${btn("Tirar foto", {
        a: "tirarFoto",
        i: "camera",
        dis: true
      })}

            ${S.f.fotoProfessor
        ? btn("Refazer foto", {
          a: "refazerFoto",
          i: "refresh-cw",
          k: "ghost"
        })
        : ""
      }

          </div>

          <p
            id="cameraStatus"
            class="text-center text-xs text-[#6B7280]"
          >
            A foto é obrigatória para enviar a reserva.
          </p>

        </div>
      </div>
    `;


    /* ================================================================
       CARD DE RESERVA
       ================================================================ */

    const resCard = (r) => {

      const d = new Date(r.data + "T00:00:00");

      return `
        <div class="${CARD} flex items-center gap-3 p-3 transition hover:shadow-md">

          <div class="w-16 shrink-0 rounded-xl bg-[#A80D25] py-2 text-center text-white">

            <p class="text-xl font-bold leading-none">
              ${d.getDate()}
            </p>

            <p class="text-xs">
              ${MESES[d.getMonth()]}
            </p>

            <p class="text-xs">
              ${d.getFullYear()}
            </p>

          </div>

          ${r.imagem
          ? `
                <img
                  src="${esc(r.imagem)}"
                  alt=""
                  class="hidden h-16 w-24 rounded-lg object-cover sm:block"
                >
              `
          : ""
        }

          ${r.fotoProfessor
          ? `
                <div class="hidden h-16 w-16 shrink-0 overflow-hidden rounded-full border-2 border-[#C8102E] sm:flex">
                  <img
                    src="${esc(r.fotoProfessor)}"
                    alt="Professor responsável"
                    class="h-full w-full object-cover"
                  >
                </div>
              `
          : ""
        }

          <div class="min-w-0 flex-1">

            <p class="truncate font-bold text-[#A80D25]">
              ${esc(r.espaco)}
            </p>

            <p class="text-xs text-[#6B7280]">
              Bloco ${esc(r.bloco)} ·
              Turma ${esc(r.turma || "--")} ·
              ${esc(r.inicio)}–${esc(r.fim)}
            </p>

            ${r.responsavel
          ? `
                  <p class="mt-1 text-xs font-semibold text-[#1E2A78]">
                    Professor: ${esc(r.responsavel)}
                  </p>
                `
          : ""
        }

          </div>

          <div class="flex flex-col items-end gap-2">

            ${badge(r.status)}

            ${btn("Ver detalhes", {
          a: "verReserva",
          v: r.id,
          i: "eye",
          k: "outline",
          c: "!px-3 !py-1.5 text-xs"
        })}

          </div>

        </div>
      `;
    };


    /* ================================================================
       CARD DE SALA
       ================================================================ */

    const roomCard = (r, a, sel) => `
      <button
        type="button"
        data-a="${a}"
        data-v="${esc(r.id)}"
        class="${CARD} overflow-hidden text-left transition hover:-translate-y-0.5 hover:shadow-md ${sel ? "ring-2 ring-[#C8102E]" : ""
      }"
      >

        <div class="relative h-32 bg-[#F8F9FA]">

          ${r.imagem
        ? `
                <img
                  src="${esc(r.imagem)}"
                  alt="${esc(r.nome)}"
                  class="h-full w-full object-cover"
                >
              `
        : ""
      }

          <span class="absolute right-2 top-2">
            ${badge(r.disponivel ? "Disponível" : "Ocupado")}
          </span>

        </div>

        <div class="p-3">

          <p class="font-bold text-[#A80D25]">
            ${esc(r.nome)}
          </p>

          <p class="text-xs text-[#6B7280]">
            Capacidade: ${esc(r.capacidade)} pessoas
          </p>

          <p class="text-xs font-semibold text-[#1E2A78]">
            Bloco ${esc(r.bloco)} · ${esc(r.piso)}
          </p>

        </div>

      </button>
    `;


    const notifItem = (n) => `
      <div class="flex gap-3 rounded-xl border p-3 ${n.lida
        ? "border-[#E5E7EB] bg-white"
        : "border-red-200 bg-red-50"
      }">

        <span class="mt-0.5 text-[#C8102E]">
          ${ic("bell", "w-[18px] h-[18px]")}
        </span>

        <div>

          <p class="text-sm font-semibold">
            ${esc(n.titulo)}
          </p>

          <p class="text-sm text-[#6B7280]">
            ${esc(n.mensagem)}
          </p>

          <p class="mt-1 text-xs text-[#9CA3AF]">
            ${esc(n.criadaEm)}
          </p>

        </div>

      </div>
    `;


    const table = (cols, rows, emptyHtml) => `
      <div class="overflow-x-auto">

        <table class="w-full min-w-[720px] text-sm">

          <thead>
            <tr class="bg-red-50 text-left text-xs text-[#A80D25]">

              ${cols
        .map(
          (c) =>
            `<th class="px-3 py-2.5 font-semibold">${c[0]}</th>`
        )
        .join("")}

            </tr>
          </thead>

          <tbody>

            ${rows
        .map(
          (r) => `
                  <tr class="border-b border-[#E5E7EB] hover:bg-[#F8F9FA]">

                    ${cols
              .map(
                (c) =>
                  `<td class="px-3 py-2.5">${c[1](r)}</td>`
              )
              .join("")}

                  </tr>
                `
        )
        .join("")}

          </tbody>

        </table>

        ${rows.length ? "" : emptyHtml}

      </div>
    `;


    const timeline = (items = []) =>
      items.length
        ? `
          <ol class="space-y-3 border-l-2 border-[#E5E7EB] pl-4">

            ${items
          .map(
            (h) => `
                  <li class="relative text-sm">

                    <span class="absolute -left-[22px] top-1 h-3 w-3 rounded-full bg-[#C8102E]"></span>

                    <b class="text-[#1E2A78]">
                      ${esc(h.status)}
                    </b>:
                    ${esc(h.em)}

                  </li>
                `
          )
          .join("")}

          </ol>
        `
        : `<p class="text-sm text-[#6B7280]">Nenhum histórico disponível.</p>`;


    const blockSelector = (sel) => `
      <div class="grid grid-cols-3 gap-3">

        ${BLOCOS.map(
      (b) => `
            <button
              type="button"
              data-a="bloco"
              data-v="${b}"
              class="${CARD} flex flex-col items-center gap-1 p-4 transition hover:shadow-md ${sel === b
          ? "bg-red-50 ring-2 ring-[#C8102E]"
          : ""
        }"
            >

              <span class="text-[#C8102E]">
                ${ic("building-2", "w-6 h-6")}
              </span>

              <span class="font-bold">
                BLOCO ${b}
              </span>

              <span class="text-xs text-[#6B7280]">
                ${sel === b ? "Selecionado" : "Selecionar"}
              </span>

            </button>
          `
    ).join("")}

      </div>
    `;


    /* ================================================================
       CALENDÁRIO NOVO
       ================================================================ */

    const calendar = () => {

      const y = S.cal.y;
      const m = S.cal.m;

      const primeiroDia = new Date(y, m, 1);
      const ultimoDia = new Date(y, m + 1, 0);

      const quantidadeDias = ultimoDia.getDate();

      /*
        Domingo = 0
        Segunda = 1
        ...
        Para o calendário começar na segunda:
        0 vira 6
        1 vira 0
        etc.
      */

      const inicio = (primeiroDia.getDay() + 6) % 7;

      const reservasMes = S.reservations.filter((r) => {

        if (!r.data || r.status === "Cancelada") {
          return false;
        }

        const d = new Date(r.data + "T00:00:00");

        return (
          d.getFullYear() === y &&
          d.getMonth() === m
        );
      });

      let dias = "";

      for (let i = 0; i < inicio; i++) {

        dias += `
          <div class="min-h-[105px] rounded-xl bg-[#F8F9FA]"></div>
        `;
      }

      for (let dia = 1; dia <= quantidadeDias; dia++) {

        const dataISO =
          `${y}-${String(m + 1).padStart(2, "0")}-${String(dia).padStart(2, "0")}`;

        const reservas = reservasMes.filter(
          (r) => r.data === dataISO
        );

        const hoje =
          dia === now.getDate() &&
          m === now.getMonth() &&
          y === now.getFullYear();

        dias += `
          <button
            type="button"
            data-a="diaCalendario"
            data-v="${dataISO}"
            class="group min-h-[105px] w-full rounded-xl border text-left ${hoje
            ? "border-[#C8102E] bg-red-50 ring-1 ring-[#C8102E]"
            : "border-[#E5E7EB] bg-white"
          } p-2 transition hover:-translate-y-0.5 hover:border-[#C8102E] hover:shadow-md focus:outline-none focus:ring-2 focus:ring-[#C8102E]/30"
            title="${reservas.length ? `Abrir ${reservas.length} reserva(s)` : "Clique para criar uma reserva nesta data"}"
          >

            <div class="mb-2 flex items-center justify-between">

              <span
                class="flex h-7 w-7 items-center justify-center rounded-full text-xs font-bold ${hoje
            ? "bg-[#C8102E] text-white"
            : "text-[#374151]"
          }"
              >
                ${dia}
              </span>

              ${reservas.length
            ? `
                    <span class="rounded-full bg-red-100 px-2 py-0.5 text-[10px] font-bold text-[#C8102E]">
                      ${reservas.length}
                    </span>
                  `
            : ""
          }

            </div>

            <div class="space-y-1">

              ${reservas.length
            ? reservas
              .slice(0, 2)
              .map(
                (r) => `
                          <button
                            type="button"
                            data-a="verReserva"
                            data-v="${esc(r.id)}"
                            class="block w-full truncate rounded-lg bg-[#C8102E] px-2 py-1.5 text-left text-[10px] font-semibold text-white hover:bg-[#A80D25]"
                            title="${esc(r.espaco)}"
                          >
                            ${esc(r.espaco)}
                          </button>
                        `
              )
              .join("")
            : `
                    <span class="inline-flex items-center gap-1 rounded-lg px-2 py-1.5 text-[10px] text-[#9CA3AF] transition group-hover:bg-red-50 group-hover:text-[#C8102E]">
                      ${ic("plus", "w-3 h-3")} Clique para reservar
                    </span>
                  `
          }

              ${reservas.length > 2
            ? `
                    <span class="block text-[10px] font-semibold text-[#6B7280]">
                      +${reservas.length - 2} reserva(s)
                    </span>
                  `
            : ""
          }

            </div>

          </button>
        `;
      }

      return `
        <div class="${CARD} overflow-hidden">

          <div class="flex flex-wrap items-center justify-between gap-3 border-b border-[#E5E7EB] p-5">

            <div>

              <p class="text-xs font-semibold uppercase tracking-wide text-[#6B7280]">
                Calendário de reservas
              </p>

              <h2 class="mt-1 text-xl font-bold text-[#A80D25]">
                ${MESES_COMPLETOS[m]} ${y}
              </h2>

            </div>

            <div class="flex items-center gap-2">

              ${btn("", {
        a: "mes",
        v: "-1",
        i: "chevron-left",
        k: "outline",
        c: "!px-3"
      })}

              ${btn("Hoje", {
        a: "mesHoje",
        k: "ghost",
        c: "!px-3"
      })}

              ${btn("", {
        a: "mes",
        v: "1",
        i: "chevron-right",
        k: "outline",
        c: "!px-3"
      })}

            </div>

          </div>

          <div class="calendar-scroll overflow-x-auto p-4">

            <div class="min-w-[720px]">

              <div class="mb-2 grid grid-cols-7 gap-2">

                ${[
          "Segunda",
          "Terça",
          "Quarta",
          "Quinta",
          "Sexta",
          "Sábado",
          "Domingo"
        ]
          .map(
            (d) => `
                      <div class="py-2 text-center text-xs font-bold uppercase text-[#6B7280]">
                        ${d}
                      </div>
                    `
          )
          .join("")}

              </div>

              <div class="grid grid-cols-7 gap-2">
                ${dias}
              </div>

            </div>

          </div>

          <div class="flex flex-wrap gap-4 border-t border-[#E5E7EB] px-5 py-3 text-xs text-[#6B7280]">

            <div class="flex items-center gap-2">
              <span class="h-3 w-3 rounded-full bg-[#C8102E]"></span>
              Reserva
            </div>

            <div class="flex items-center gap-2">
              <span class="h-3 w-3 rounded-full border border-[#C8102E] bg-red-50"></span>
              Hoje
            </div>

          </div>

        </div>
      `;
    };


    /* ================================================================
       LAYOUT
       ================================================================ */

    const nav = (k, l, i) => {

      const paginaAtiva =
        {
          reservation: "reservations",
          room: "rooms",
          new: "reservations"
        }[S.page] || S.page;

      const ativo = paginaAtiva === k;

      return `
        <a
          href="${href(k)}"
          class="relative flex w-full items-center gap-3 rounded-xl px-4 py-2.5 text-sm font-semibold transition ${ativo
          ? "bg-white text-[#C8102E] shadow-sm"
          : "text-white hover:bg-white/10"
        }"
        >

          ${ativo
          ? `<span class="absolute bottom-2 left-0 top-2 w-1 rounded-r bg-[#C8102E]"></span>`
          : ""
        }

          ${ic(i, "w-[18px] h-[18px]")}

          ${l}

        </a>
      `;
    };


    const modal = () =>
      S.ui.modal
        ? `
          <div
            class="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4"
            data-a="modal"
            data-v="0"
          >

            <div class="${CARD} w-full max-w-md p-6">

              <h3 class="mb-2 font-bold">
                Cancelar esta reserva?
              </h3>

              <p class="text-sm text-[#6B7280]">
                Depois de cancelada, a reserva não poderá ser recuperada.
              </p>

              <div class="mt-5 flex justify-end gap-2">

                ${btn("Voltar", {
          a: "modal",
          v: "0",
          k: "ghost"
        })}

                ${btn("Cancelar reserva", {
          a: "cancelarReserva"
        })}

              </div>

            </div>

          </div>
        `
        : "";


    const layout = (c) => {

      const unread =
        S.notifications.filter(
          (n) => !n.lida
        ).length;

      return `
        <div class="min-h-screen">

          ${S.menu
          ? `
                <div
                  class="fixed inset-0 z-30 bg-black/40 lg:hidden"
                  data-a="menu"
                  data-v="0"
                ></div>
              `
          : ""
        }

          <aside
            class="fixed inset-y-0 left-0 z-40 flex w-64 flex-col bg-[#C8102E] p-4 transition-transform lg:translate-x-0 ${S.menu
          ? "translate-x-0"
          : "-translate-x-full"
        }"
          >

            <div class="mb-6 px-2">

              ${logo}

              <p class="mt-2 text-sm font-semibold text-white">
                Reserva de Espaços
              </p>

            </div>

            <nav class="flex-1 space-y-1">
              ${NAV.map((n) => nav(...n)).join("")}
            </nav>

            <div class="space-y-1 border-t border-white/30 pt-3">

              ${nav(
          "notifications",
          "Notificações",
          "bell"
        )}

              ${nav(
          "login",
          "Sair",
          "log-out"
        )}

            </div>

          </aside>


          <div class="lg:pl-64">

            <header class="flex items-center justify-between px-4 py-4 lg:px-8">

              <div class="flex items-center gap-3">

                <button
                  type="button"
                  class="lg:hidden"
                  data-a="menu"
                  data-v="1"
                  aria-label="Abrir menu"
                >
                  ${ic("menu", "w-6 h-6")}
                </button>

                <h1 class="text-xl font-bold">
                  ${TITULOS[S.page] || "SENAI"}
                </h1>

              </div>


              <div class="flex items-center gap-3">

                <button
                  type="button"
                  data-a="go"
                  data-v="notifications"
                  class="relative rounded-full p-2 text-[#C8102E] transition hover:bg-red-50"
                >

                  ${ic("bell", "w-5 h-5")}

                  ${unread
          ? `<span class="absolute right-1 top-1 h-2.5 w-2.5 rounded-full bg-[#1E2A78]"></span>`
          : ""
        }

                </button>


                <button
                  type="button"
                  data-a="go"
                  data-v="profile"
                  class="flex items-center gap-2"
                >

                  ${avatar(S.user?.nome, 40, S.ui.fotoPerfil || S.user?.foto)}

                  <span class="hidden text-left text-sm sm:block">

                    <b class="block">
                      ${esc(S.user?.nome || "Usuário")}
                    </b>

                    <span class="text-xs text-[#6B7280]">
                      ${esc(S.user?.tipo || "Perfil")}
                    </span>

                  </span>

                </button>

              </div>

            </header>

            ${c}

          </div>

          ${modal()}

        </div>
      `;
    };


    const authShell = (left, body) => `
      <div class="grid min-h-screen lg:grid-cols-2">

        <div class="relative hidden flex-col overflow-hidden bg-[#C8102E] p-12 text-white lg:flex">
          <img src="${(IN_PAGES ? "../" : "") + "assets/imagens/senai-fachada.jpg"}" alt="" aria-hidden="true" class="absolute inset-0 h-full w-full object-cover">
          <div class="absolute inset-0 bg-gradient-to-b from-[#C8102E]/90 via-[#C8102E]/75 to-[#8F0B21]/95"></div>
          <div class="relative z-10 flex flex-1 flex-col justify-between">
            ${left}
          </div>
        </div>

        <div class="relative flex items-center justify-center p-6 pb-12">

          <a
            href="${href("adminLogin")}"
            class="absolute bottom-3 right-4 inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium text-[#6B7280] transition hover:bg-white hover:text-[#1E2A78]"
          >
            ${ic("shield-check", "w-3.5 h-3.5")}
            Entrar como ADM
          </a>

          <div class="${CARD} w-full max-w-md p-8">

            <img src="${(IN_PAGES ? "../" : "") + "assets/imagens/senai-logo.png"}" alt="SENAI · Reserva de Espaços" width="140" height="36" class="mb-5 h-auto w-32 rounded-md lg:hidden">

            ${body}

          </div>

        </div>

      </div>
    `;


    const perk = (i, t) => `
      <div class="flex max-w-[10rem] items-center gap-3">

        <span class="rounded-xl bg-white/20 p-3">
          ${ic(i, "w-[22px] h-[22px]")}
        </span>

        <span class="text-sm font-semibold">
          ${t}
        </span>

      </div>
    `;


    /* ================================================================
       LOGIN
       ================================================================ */

    const login = () =>
      authShell(
        `
          <div>
            ${logo}

            <p class="mt-2 text-sm">
              Reserva de Espaços
            </p>
          </div>

          <div>

            <h1 class="text-4xl font-bold leading-tight">
              Bem-vindo ao sistema do SENAI
            </h1>

            <p class="mt-3 max-w-md text-white/85">
              Reserve salas e espaços de forma rápida e organizada para as suas atividades.
            </p>

          </div>

          <div class="flex gap-8">

            ${perk(
          "calendar-days",
          "Reserve salas e espaços"
        )}

            ${perk(
          "clock",
          "Acompanhe seus agendamentos"
        )}

          </div>
        `,
        `
          <h2 class="text-2xl font-bold text-[#C8102E]">
            Faça login para continuar
          </h2>

          <p class="mb-6 text-sm text-[#6B7280]">
            Acesse sua conta para gerenciar suas reservas e espaços.
          </p>

          <form data-form="login" class="space-y-4">

            ${input(
          "E-mail ou usuário",
          "email",
          {
            icon: "user",
            ph: "Digite seu e-mail",
            req: false
          }
        )}

            ${input(
          "Senha",
          "senha",
          {
            type: "password",
            icon: "lock",
            ph: "Digite sua senha",
            req: false
          }
        )}

            <div class="flex items-center justify-between text-sm">

              <label class="flex items-center gap-2">
                <input
                  type="checkbox"
                  class="accent-[#C8102E]"
                >
                Lembrar de mim
              </label>

              <button
                type="button"
                class="text-[#C8102E] hover:underline"
              >
                Esqueci minha senha
              </button>

            </div>

            ${btn("Entrar", {
          type: "submit",
          c: "w-full"
        })}

          </form>

          <p class="mt-6 text-center text-sm text-[#6B7280]">

            Ainda não tem uma conta?

            <button
              type="button"
              data-a="go"
              data-v="register"
              class="font-semibold text-[#C8102E] hover:underline"
            >
              Criar conta
            </button>

          </p>
        `
      );


    /* ================================================================
       CADASTRO
       ================================================================ */

    const register = () =>
      authShell(
        `
          ${logo}

          <h1 class="text-4xl font-bold leading-tight">
            Juntos por um ambiente de aprendizado ainda melhor!
          </h1>

          <p class="max-w-md text-white/85">
            Cadastre-se para acessar o sistema e gerenciar suas reservas, solicitações e espaços de forma simples e rápida.
          </p>
        `,
        `
          <h2 class="text-2xl font-bold text-[#C8102E]">
            Criar conta
          </h2>

          <p class="mb-5 text-sm text-[#6B7280]">
            Preencha os dados abaixo para acessar o sistema.
          </p>

          <form data-form="cadastro" class="grid gap-3 sm:grid-cols-2">

            <div class="sm:col-span-2">
              ${input(
          "Nome completo",
          "nome",
          {
            icon: "user",
            ph: "Digite seu nome completo"
          }
        )}
            </div>

            <div class="sm:col-span-2">
              ${input(
          "E-mail institucional",
          "email",
          {
            icon: "mail",
            type: "email",
            ph: "exemplo@senai.br"
          }
        )}
            </div>

            ${input("CPF", "cpf", {
          ph: "000.000.000-00"
        })}

            ${input(
          "Data de nascimento",
          "nasc",
          {
            type: "date"
          }
        )}

            ${input("Telefone", "tel", {
          ph: "(00) 00000-0000",
          req: false
        })}

            ${input("Matrícula", "mat")}

            <div class="sm:col-span-2">

              ${select(
          "Tipo de usuário",
          "tipo",
          [
            "Docente",
            "Funcionário",
            "Coordenador",
            "Administrador"
          ],
          {
            ph: "Selecione o seu perfil",
            req: true
          }
        )}

            </div>

            ${input(
          "Senha",
          "senha",
          {
            type: "password",
            icon: "lock",
            ph: "Crie uma senha"
          }
        )}

            ${input(
          "Confirmar senha",
          "conf",
          {
            type: "password",
            icon: "lock",
            ph: "Repita a senha"
          }
        )}

            ${msgHtml()}

            ${btn("Criar conta", {
          type: "submit",
          c: "sm:col-span-2"
        })}

            ${btn("Voltar para o login", {
          a: "go",
          v: "login",
          i: "arrow-left",
          k: "outline",
          c: "sm:col-span-2"
        })}

          </form>
        `
      );


    /* ================================================================
       FILTRO DE PERÍODO
       ================================================================ */

    const noPeriodo = (r, p) => {

      if (!p) return true;

      const a = new Date(
        r.data + "T00:00:00"
      );

      const diferenca =
        (a.getFullYear() - now.getFullYear()) * 12 +
        a.getMonth() -
        now.getMonth();

      return diferenca === (
        p === "Este mês" ? 0 : 1
      );
    };


    /* ================================================================
       SENHA
       ================================================================ */

    const senhaForm = () => {

      const p = S.f.n || "";
      const s = forca(p);

      return `
        <form data-form="senha" class="max-w-md space-y-4">

          ${ttl("lock", "Alterar senha")}

          ${input(
        "Senha atual",
        "a",
        {
          type: "password",
          icon: "lock"
        }
      )}

          ${input(
        "Nova senha",
        "n",
        {
          type: "password",
          icon: "lock",
          r: true
        }
      )}

          ${p
          ? `
                <div>

                  <div class="flex gap-1">

                    ${[1, 2, 3, 4]
            .map(
              (i) => `
                          <span
                            class="h-1.5 flex-1 rounded-full ${i <= s
                  ? [
                    "",
                    "bg-rose-400",
                    "bg-yellow-400",
                    "bg-green-400",
                    "bg-green-600"
                  ][s]
                  : "bg-gray-200"
                }"
                          ></span>
                        `
            )
            .join("")}

                  </div>

                  <p class="mt-1 text-xs text-[#6B7280]">
                    Força:
                    ${[
            "Muito fraca",
            "Fraca",
            "Média",
            "Forte",
            "Muito forte"
          ][s]
          }
                  </p>

                </div>
              `
          : ""
        }

          ${input(
          "Confirmar nova senha",
          "c",
          {
            type: "password",
            icon: "lock"
          }
        )}

          ${msgHtml()}

          ${btn("Alterar senha", {
          type: "submit"
        })}

        </form>
      `;
    };


    /* ================================================================
       TELAS
       ================================================================ */

    const views = {

      /* ================= HOME ================= */

      home: () => {

        const prox = S.reservations
          .filter(
            (r) => r.status !== "Cancelada"
          )
          .slice(0, 3);

        return pg(`

          <div class="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">

            ${stat(
          "clock",
          "Reservas",
          S.reservations.length,
          "cadastradas",
          "reservations"
        )}

            ${stat(
          "clipboard-list",
          "Solicitações",
          S.requests.length,
          "enviadas",
          "requests"
        )}

            ${stat(
          "bell",
          "Notificações",
          S.notifications.filter(
            (n) => !n.lida
          ).length,
          "não lidas",
          "notifications"
        )}

            ${stat(
          "building-2",
          "Salas disponíveis",
          S.rooms.filter(
            (r) => r.disponivel
          ).length,
          "para reservar",
          "rooms"
        )}

          </div>


          <div class="grid gap-6 lg:grid-cols-3">

            <div class="${CARD} p-5 lg:col-span-2">

              ${ttl(
          "calendar-days",
          "Próximas reservas"
        )}

              ${prox.length
            ? `
                    <div class="mt-4 space-y-3">
                      ${prox.map(resCard).join("")}
                    </div>
                  `
            : empty(
              "calendar-days",
              "Nenhuma reserva encontrada",
              "Você ainda não possui reservas cadastradas."
            )
          }

            </div>


            <div class="${CARD} space-y-3 p-5">

              ${ttl("plus", "Acessos rápidos")}

              ${btn("Nova reserva", {
            a: "go",
            v: "new",
            i: "plus",
            c: "w-full"
          })}

              ${btn("Ver salas", {
            a: "go",
            v: "rooms",
            i: "building-2",
            k: "outline",
            c: "w-full"
          })}

              ${btn("Minhas reservas", {
            a: "go",
            v: "reservations",
            i: "clock",
            k: "outline",
            c: "w-full"
          })}

            </div>

          </div>
        `);
      },


      /* ================= MINHAS RESERVAS ================= */

      reservations: () => {

        const f = S.f;

        const lista = S.reservations.filter(
          (r) =>
            (!f.ft || r.tipo === f.ft) &&
            (!f.fs || r.status === f.fs) &&
            (
              !f.fq ||
              String(r.espaco || "")
                .toLowerCase()
                .includes(
                  String(f.fq).toLowerCase()
                )
            ) &&
            noPeriodo(r, f.fp)
        );

        return pg(`

          <div class="${CARD} grid gap-3 p-4 sm:grid-cols-2 lg:grid-cols-5">

            ${select(
          "Período",
          "fp",
          [
            "Este mês",
            "Próximo mês"
          ],
          {
            ph: "Todos",
            r: true
          }
        )}

            ${select(
          "Tipo",
          "ft",
          TIPOS,
          {
            ph: "Todos",
            r: true
          }
        )}

            ${select(
          "Status",
          "fs",
          [
            "Confirmada",
            "Em análise",
            "Cancelada",
            "Recusada"
          ],
          {
            ph: "Todos",
            r: true
          }
        )}

            ${input(
          "Pesquisa",
          "fq",
          {
            icon: "search",
            ph: "Buscar espaço",
            req: false,
            r: true
          }
        )}

            <div class="flex items-end">

              ${btn("Limpar filtros", {
          a: "limpar",
          i: "filter",
          k: "outline",
          c: "w-full"
        })}

            </div>

          </div>


          <div class="grid gap-6 xl:grid-cols-[minmax(0,1fr)_minmax(620px,760px)]">

            <div>

              ${ttl(
          "clock",
          "Suas reservas",
          `<span class="text-xs text-[#6B7280]">Total: ${lista.length}</span>`
        )}

              <div class="mt-3 space-y-3">

                ${lista.length
            ? lista.map(resCard).join("")
            : `
                      <div class="${CARD}">
                        ${empty(
              "calendar-days",
              "Nenhuma reserva encontrada",
              "Você ainda não possui reservas cadastradas.",
              btn("Nova reserva", {
                a: "go",
                v: "new",
                i: "plus"
              })
            )}
                      </div>
                    `
          }

              </div>

            </div>


            ${calendar()}

          </div>

        `);
      },


      /* ================= DETALHES RESERVA ================= */

      reservation: () => {

        const r = S.sel.reservation;

        const linhas = r
          ? [
            ["Espaço", r.espaco],
            ["Bloco", r.bloco],
            ["Piso", r.piso],
            [
              "Data",
              new Date(
                r.data + "T00:00:00"
              ).toLocaleDateString(
                "pt-BR",
                {
                  dateStyle: "full"
                }
              )
            ],
            [
              "Horário",
              `${r.inicio} – ${r.fim}`
            ],
            ["Responsável", r.responsavel],
            ["Turma", r.turma],
            ["Finalidade", r.finalidade],
            [
              "Quantidade de pessoas",
              r.pessoas
            ],
            ["Descrição", r.descricao],
            ...(r.motivoRecusa
              ? [["Motivo da recusa", r.motivoRecusa]]
              : [])
          ]
          : [];

        return pg(`

          ${back("reservations")}

          <div class="grid gap-6 lg:grid-cols-[1fr_320px]">

            <div class="${CARD} p-5">

              ${r
            ? `

                    <div class="mb-4 flex items-center justify-between">

                      <h2 class="font-bold text-[#A80D25]">
                        Informações da reserva
                      </h2>

                      ${badge(r.status)}

                    </div>

                    ${r.imagem
              ? `
                          <img
                            src="${esc(r.imagem)}"
                            alt=""
                            class="mb-4 h-48 w-full rounded-xl object-cover"
                          >
                        `
              : ""
            }

                    ${r.fotoProfessor
              ? `
                          <div class="mb-5 flex items-center gap-4 rounded-xl bg-[#F8F9FA] p-4">

                            <img
                              src="${esc(r.fotoProfessor)}"
                              alt="Professor responsável"
                              class="h-20 w-20 rounded-full border-2 border-[#C8102E] object-cover"
                            >

                            <div>

                              <p class="text-xs text-[#6B7280]">
                                Professor responsável
                              </p>

                              <p class="font-bold text-[#1E2A78]">
                                ${esc(
                r.responsavel ||
                "Professor"
              )}
                              </p>

                              <p class="mt-1 text-xs text-[#6B7280]">
                                Foto registrada no momento da reserva.
                              </p>

                            </div>

                          </div>
                        `
              : ""
            }

                    <dl class="grid gap-3 sm:grid-cols-2">

                      ${linhas
              .map(
                ([k, v]) => `
                            <div>

                              <dt class="text-xs text-[#6B7280]">
                                ${k}
                              </dt>

                              <dd class="text-sm font-semibold text-[#1E2A78]">
                                ${esc(v) || "--"}
                              </dd>

                            </div>
                          `
              )
              .join("")}

                    </dl>

                  `
            : empty(
              "calendar-days",
              "Nenhuma reserva selecionada",
              "Selecione uma reserva para visualizar seus detalhes."
            )
          }

            </div>


            <div class="space-y-6">

              <div class="${CARD} space-y-3 p-5">

                <h2 class="font-bold text-[#A80D25]">
                  Ações
                </h2>

                ${btn("Alterar reserva", {
            a: "go",
            v: "new",
            i: "pencil",
            k: "navy",
            c: "w-full",
            dis: !r
          })}

                ${btn("Cancelar reserva", {
            a: "modal",
            v: "1",
            i: "trash-2",
            k: "danger",
            c: "w-full",
            dis: !r
          })}

              </div>


              <div class="${CARD} p-5">

                <h2 class="mb-3 flex items-center gap-2 font-bold text-[#A80D25]">
                  ${ic("clock", "w-[18px] h-[18px]")}
                  Histórico da reserva
                </h2>

                ${timeline(r?.historico)}

              </div>

            </div>

          </div>

        `);
      },


      /* ================= SALAS ================= */

      rooms: () => {

        const t = S.ui.tipo || "Todos";

        const lista = S.rooms.filter(
          (r) =>
            t === "Todos" ||
            r.tipo === t
        );

        return pg(`

          <div class="flex flex-wrap gap-2">

            ${["Todos", ...TIPOS]
            .map(
              (c) => `
                  <button
                    type="button"
                    data-a="tipo"
                    data-v="${esc(c)}"
                    class="rounded-full border border-[#C8102E] px-4 py-1.5 text-sm font-semibold transition ${t === c
                  ? "bg-[#C8102E] text-white"
                  : "text-[#C8102E] hover:bg-red-50"
                }"
                  >
                    ${esc(c)}
                  </button>
                `
            )
            .join("")}

          </div>


          ${lista.length
            ? `
                <div class="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
                  ${lista
              .map(
                (r) =>
                  roomCard(
                    r,
                    "verSala"
                  )
              )
              .join("")}
                </div>
              `
            : `
                <div class="${CARD}">
                  ${empty(
              "building-2",
              "Nenhum espaço cadastrado",
              "Os espaços disponíveis serão exibidos aqui quando forem cadastrados."
            )}
                </div>
              `
          }

        `);
      },


      /* ================= SALA ================= */

      room: () => {

        const r = S.sel.room;

        return pg(`

          ${back("rooms")}

          <div class="${CARD} p-5">

            ${r
            ? `

                  ${r.imagem
              ? `
                        <img
                          src="${esc(r.imagem)}"
                          alt="${esc(r.nome)}"
                          class="mb-4 h-64 w-full rounded-xl object-cover"
                        >
                      `
              : ""
            }

                  <div class="flex flex-wrap items-center justify-between gap-2">

                    <h2 class="text-xl font-bold text-[#A80D25]">
                      ${esc(r.nome)}
                    </h2>

                    ${badge(
              r.disponivel
                ? "Disponível"
                : "Ocupado"
            )}

                  </div>

                  <div class="my-4 grid gap-3 text-sm sm:grid-cols-3">

                    ${[
              [
                "users",
                "Capacidade",
                `${r.capacidade} pessoas`
              ],
              [
                "building-2",
                "Tipo",
                r.tipo
              ],
              [
                "map-pin",
                "Localização",
                `Bloco ${r.bloco} · ${r.piso}`
              ]
            ]
              .map(
                ([i, k, v]) => `
                          <div class="flex items-center gap-3">

                            <span class="text-[#C8102E]">
                              ${ic(i, "w-5 h-5")}
                            </span>

                            <div>

                              <p class="text-xs text-[#6B7280]">
                                ${k}
                              </p>

                              <p class="font-semibold">
                                ${esc(v)}
                              </p>

                            </div>

                          </div>
                        `
              )
              .join("")}

                  </div>

                  <h3 class="font-bold">
                    Descrição
                  </h3>

                  <p class="mb-4 text-sm text-[#6B7280]">
                    ${esc(r.descricao)}
                  </p>

                  <h3 class="mb-2 font-bold">
                    Equipamentos
                  </h3>

                  <div class="mb-5 flex flex-wrap gap-3">

                    ${(r.equipamentos || [])
              .map(
                (e) => `
                          <span class="flex items-center gap-2 rounded-xl border border-[#E5E7EB] px-3 py-2 text-sm">

                            <span class="text-[#C8102E]">
                              ${ic(
                  EQUIP[e] || "plug"
                )}
                            </span>

                            ${esc(e)}

                          </span>
                        `
              )
              .join("")}

                  </div>

                  ${btn(
                "Reservar este espaço",
                {
                  a: "reservarSala",
                  i: "plus"
                }
              )}

                `
            : empty(
              "building-2",
              "Nenhum espaço selecionado",
              "Selecione um espaço para visualizar seus detalhes."
            )
          }

          </div>
        `);
      },


     /* ================= NOVA RESERVA ================= */

new: () => {

  const b = S.ui.bloco;
  const sala = S.ui.sala;

  const salas = S.rooms.filter(
    r => r.bloco === b
  );

  return pg(`

    <form data-form="nova" class="space-y-6">

      <section class="${CARD} p-5">

        ${step(
          1,
          "Escolha o bloco"
        )}

        ${blockSelector(b)}

      </section>


      <section class="${CARD} p-5">

        ${step(
          2,
          "Escolha a sala"
        )}

        ${!b
          ? `
              <p class="text-sm text-[#6B7280]">
                Selecione um bloco para ver as salas.
              </p>
            `
          : salas.length
            ? `
                <div class="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">

                  ${salas
                    .map(
                      r =>
                        roomCard(
                          r,
                          "sala",
                          sala &&
                          String(sala.id) === String(r.id)
                        )
                    )
                    .join("")}

                </div>
              `
            : empty(
                "building-2",
                "Nenhuma sala cadastrada neste bloco.",
                "As salas disponíveis serão exibidas aqui quando forem cadastradas."
              )
        }

      </section>


      <section class="${CARD} p-5">

        ${step(
          3,
          "Data, horário e detalhes"
        )}

        <div class="grid gap-4 sm:grid-cols-2">

          ${input(
            "Data",
            "data",
            {
              type: "date"
            }
          )}

          ${input(
            "Turma",
            "turma"
          )}

          ${input(
            "Horário inicial",
            "ini",
            {
              type: "time"
            }
          )}

          ${input(
            "Horário final",
            "fim",
            {
              type: "time"
            }
          )}

          ${input(
            "Finalidade",
            "fin"
          )}

          ${input(
            "Quantidade de pessoas",
            "pes",
            {
              type: "number",
              extra: 'min="1"'
            }
          )}

          ${cameraFoto()}

          <div class="sm:col-span-2">

            ${field(
              "Observações",
              `
                <textarea
                  data-k="obs"
                  rows="3"
                  class="${FLD}"
                >${esc(S.f.obs)}</textarea>
              `
            )}

          </div>

        </div>

      </section>


      ${msgHtml()}


      ${btn("Solicitar reserva", {
        type: "submit",
        i: "check",
        dis: !sala || !S.f.fotoProfessor
      })}


    </form>

  `);
},
      /* ================= SOLICITAÇÕES ================= */

      requests: () => {

        const n = (s) =>
          S.requests.filter(
            (r) => r.status === s
          ).length;

        return pg(`

          <div class="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">

            ${stat(
          "clipboard-list",
          "Total",
          S.requests.length
        )}

            ${stat(
          "clock",
          "Em análise",
          n("Em análise")
        )}

            ${stat(
          "check-circle-2",
          "Aprovadas",
          n("Aprovada")
        )}

            ${stat(
          "x-circle",
          "Recusadas",
          n("Recusada")
        )}

          </div>


          <div class="${CARD} p-5">

            ${ttl(
          "clipboard-list",
          "Lista de solicitações"
        )}

            <div class="mt-4">

              ${table(
          [
            [
              "Nº",
              (r) => esc(r.numero)
            ],
            [
              "Espaço",
              (r) => esc(r.espaco)
            ],
            [
              "Tipo",
              (r) => esc(r.tipo)
            ],
            [
              "Descrição",
              (r) => esc(r.descricao)
            ],
            [
              "Data",
              (r) => esc(r.criadaEm)
            ],
            [
              "Data da reserva",
              (r) => esc(r.dataReserva)
            ],
            [
              "Status",
              (r) => badge(r.status)
            ],
            [
              "Ações",
              () => `
                      <button
                        type="button"
                        class="text-[#1E2A78] hover:text-[#C8102E]"
                      >
                        ${ic("eye")}
                      </button>
                    `
            ]
          ],
          S.requests,
          empty(
            "clipboard-list",
            "Nenhuma solicitação encontrada",
            "Suas solicitações aparecerão aqui quando forem enviadas."
          )
        )}

            </div>

          </div>
        `);
      },


      /* ================= PERFIL ================= */

      profile: () => {

        const ed = S.ui.edit;
        const tab = S.ui.ptab || "info";

        const tb = (k, l, i) => `
          <button
            type="button"
            data-a="ptab"
            data-v="${k}"
            class="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-sm font-semibold transition ${tab === k
            ? "bg-indigo-100 text-[#1E2A78]"
            : "text-[#6B7280] hover:bg-gray-100"
          }"
          >
            ${ic(i)}
            ${l}
          </button>
        `;

        return pg(`

          <div class="grid gap-6 lg:grid-cols-[280px_1fr]">

            <div class="${CARD} flex h-fit flex-col items-center gap-3 p-5">

              ${avatarEditavel(
          S.user?.nome,
          80,
          S.ui.fotoPerfil || S.user?.foto
        )}

              <p class="font-bold">
                ${esc(
          S.user?.nome ||
          "Usuário"
        )}
              </p>

              <p class="text-xs text-[#6B7280]">
                ${esc(
          S.user?.tipo ||
          "Tipo não informado"
        )}
              </p>

              <div class="flex items-center gap-2">

                ${btn(
          "Trocar foto",
          {
            a: "abrirSeletorFoto",
            i: "camera",
            k: "outline"
          }
        )}

                ${(S.ui.fotoPerfil || S.user?.foto)
          ? btn(
            "Remover",
            {
              a: "removerFotoPerfil",
              k: "ghost"
            }
          )
          : ""
        }

              </div>

              ${S.ui.fotoMsg
          ? `
                    <p class="text-center text-xs ${S.ui.fotoMsg[0] === "err"
            ? "text-rose-700"
            : "text-green-700"
          }">
                      ${esc(S.ui.fotoMsg[1])}
                    </p>
                  `
          : ""
        }

              <div class="w-full space-y-1">

                ${tb(
          "info",
          "Informações pessoais",
          "user"
        )}

                ${tb(
          "senha",
          "Alterar senha",
          "lock"
        )}

              </div>

            </div>


            <div class="${CARD} p-5">

              ${tab === "senha"
            ? senhaForm()
            : `

                    ${ttl(
              "user",
              "Informações pessoais",
              ed
                ? ""
                : btn(
                  "Editar perfil",
                  {
                    a: "editar",
                    i: "pencil",
                    k: "outline"
                  }
                )
            )}

                    <div class="mt-4 grid gap-4 sm:grid-cols-2">

                      ${CAMPOS.map(
              ([k, l]) =>
                input(
                  l,
                  "p_" + k,
                  {
                    req: false,
                    dis: !ed,
                    type:
                      k ===
                        "nascimento"
                        ? "date"
                        : "text"
                  }
                )
            ).join("")}

                    </div>

                    ${ed
              ? `
                          <div class="mt-5 flex justify-end gap-2">

                            ${btn(
                "Cancelar",
                {
                  a: "cancelarEd",
                  k: "ghost"
                }
              )}

                            ${btn(
                "Salvar",
                {
                  a: "salvar"
                }
              )}

                          </div>
                        `
              : ""
            }

                  `
          }

            </div>

          </div>
        `);
      },


      /* ================= NOTIFICAÇÕES ================= */

      notifications: () => {

        const t =
          S.ui.ntab || "todas";

        const N = S.notifications;

        const cont = (k) =>
          k === "todas"
            ? N.length
            : N.filter(
              (n) =>
                n.categoria === k
            ).length;

        const lista = N.filter(
          (n) =>
            t === "todas" ||
            n.categoria === t
        );

        return pg(`

          <div class="${CARD} p-5">

            <div class="mb-4 flex flex-wrap items-center justify-between gap-3">

              <div class="flex flex-wrap gap-2">

                ${[
            ["todas", "Todas"],
            [
              "reservas",
              "Reservas"
            ],
            [
              "solicitacoes",
              "Solicitações"
            ],
            ["avisos", "Avisos"]
          ]
            .map(
              ([k, x]) => `
                      <button
                        type="button"
                        data-a="ntab"
                        data-v="${k}"
                        class="flex items-center gap-2 rounded-full border border-[#1E2A78] px-3 py-1 text-sm font-semibold transition ${t === k
                  ? "bg-[#1E2A78] text-white"
                  : "text-[#1E2A78] hover:bg-indigo-50"
                }"
                      >

                        ${x}

                        <span class="rounded-full bg-indigo-100 px-1.5 text-xs text-[#1E2A78]">
                          ${cont(k)}
                        </span>

                      </button>
                    `
            )
            .join("")}

              </div>

              ${btn(
              "Marcar todas como lidas",
              {
                a: "lidas",
                i: "check",
                k: "ghost",
                dis:
                  !N.some(
                    (n) => !n.lida
                  )
              }
            )}

            </div>


            ${lista.length
            ? `
                  <div class="space-y-2">
                    ${lista
              .map(notifItem)
              .join("")}
                  </div>
                `
            : empty(
              "bell",
              "Você não possui notificações",
              "Novas notificações aparecerão aqui."
            )
          }

          </div>
        `);
      }

    };


    /* ================================================================
       RENDER
       ================================================================ */

    function render() {

      const k =
        document.activeElement?.dataset?.k;

      const pagina =
        S.page === "login"
          ? login()
          : S.page === "register"
            ? register()
            : layout(
              views[S.page]
                ? views[S.page]()
                : views.home()
            );

      $("#app").innerHTML = pagina;

      if (
        window.lucide &&
        typeof lucide.createIcons ===
        "function"
      ) {
        lucide.createIcons();
      }

      if (k) {

        const el = $(
          `[data-k="${k}"]`
        );

        if (el) {

          el.focus();

          try {
            el.setSelectionRange(
              el.value.length,
              el.value.length
            );
          } catch { }

        }
      }
    }


    /* ================================================================
       NAVEGAÇÃO
       ================================================================ */

    function go(p, o = {}) {
      const target = href(p);

      const params = new URLSearchParams();

      if (o.reservation?.id !== undefined) {
        params.set("id", o.reservation.id);
      }
      if (o.room?.id !== undefined) {
        params.set("id", o.room.id);
      }
      if (p === "new" && o.sala?.id !== undefined) {
        params.set("sala", o.sala.id);
      }
      if (p === "new" && o.data) {
        params.set("data", o.data);
      }

      const query = params.toString();
      window.location.href = target + (query ? "?" + query : "");
    }


    const find = (list, id) =>
      list.find(
        (x) =>
          String(x.id) ===
          String(id)
      );


    /* ================================================================
       AÇÕES
       ================================================================ */

    const act = {

      /* CAMERA */

      abrirCamera: async () => {

        try {

          const video =
            document.querySelector(
              "#cameraVideo"
            );

          const status =
            document.querySelector(
              "#cameraStatus"
            );

          const tirar =
            document.querySelector(
              '[data-a="tirarFoto"]'
            );

          if (
            !navigator.mediaDevices ||
            !navigator.mediaDevices
              .getUserMedia
          ) {

            if (status) {

              status.textContent =
                "Seu navegador não permite acesso à câmera. Use HTTPS ou localhost.";

              status.className =
                "text-center text-xs text-rose-700";
            }

            return;
          }

          const stream =
            await navigator.mediaDevices.getUserMedia(
              {
                video: {
                  facingMode: "user",
                  width: {
                    ideal: 720
                  },
                  height: {
                    ideal: 720
                  }
                },
                audio: false
              }
            );

          S.ui.cameraStream =
            stream;

          if (!video) return;

          video.srcObject =
            stream;

          video.classList.remove(
            "hidden"
          );

          if (tirar) {
            tirar.disabled = false;
          }

          if (status) {

            status.textContent =
              "Posicione o rosto dentro da câmera e tire a foto.";

            status.className =
              "text-center text-xs text-green-700";
          }

        } catch (err) {

          console.error(
            "Erro ao abrir câmera:",
            err
          );

          const status =
            document.querySelector(
              "#cameraStatus"
            );

          if (status) {

            status.textContent =
              "Não foi possível acessar a câmera. Verifique a permissão do navegador.";

            status.className =
              "text-center text-xs text-rose-700";
          }

        }
      },


      tirarFoto: () => {

        const video =
          document.querySelector(
            "#cameraVideo"
          );

        const canvas =
          document.querySelector(
            "#cameraCanvas"
          );

        if (
          !video ||
          !canvas ||
          !video.srcObject
        ) {
          return;
        }

        canvas.width =
          video.videoWidth || 720;

        canvas.height =
          video.videoHeight || 720;

        const ctx =
          canvas.getContext("2d");

        ctx.drawImage(
          video,
          0,
          0,
          canvas.width,
          canvas.height
        );

        S.f.fotoProfessor =
          canvas.toDataURL(
            "image/jpeg",
            0.85
          );

        if (S.ui.cameraStream) {

          S.ui.cameraStream
            .getTracks()
            .forEach(
              (track) =>
                track.stop()
            );

          S.ui.cameraStream =
            null;
        }

        video.srcObject = null;

        render();
      },


      refazerFoto: () => {

        if (S.ui.cameraStream) {

          S.ui.cameraStream
            .getTracks()
            .forEach(
              (track) =>
                track.stop()
            );

          S.ui.cameraStream =
            null;
        }

        S.f.fotoProfessor =
          "";

        render();

        setTimeout(() => {

          document
            .querySelector(
              '[data-a="abrirCamera"]'
            )
            ?.click();

        }, 100);

      },


      /* NAVEGAÇÃO */

      go: (v) => {

        /*
          Proteção extra para garantir
          que Minhas Reservas sempre abra.
        */

        go(v);
      },


      menu: (v) => {

        S.menu =
          v === "1";

        render();
      },


      modal: (v) => {

        S.ui.modal =
          v === "1";

        render();
      },


      bloco: (v) => {

        S.ui.bloco =
          v;

        S.ui.sala =
          null;

        render();
      },


      sala: (v) => {

        S.ui.sala =
          find(
            S.rooms,
            v
          );

        render();
      },


      verSala: (v) => {

        go("room", {
          room: find(
            S.rooms,
            v
          )
        });

      },


      verReserva: (v) => {

        go("reservation", {
          reservation:
            find(
              S.reservations,
              v
            )
        });

      },


      reservarSala: () => {

        go("new", {
          sala:
            S.sel.room
        });

      },


      tipo: (v) => {

        S.ui.tipo =
          v;

        render();
      },


      ntab: (v) => {

        S.ui.ntab =
          v;

        render();
      },


      ptab: (v) => {

        S.ui.ptab =
          v;

        S.ui.msg =
          null;

        render();
      },


      diaCalendario: (v) => {

        // Clicar em qualquer dia abre a nova reserva já com a data preenchida.
        // Se houver reservas, elas continuam acessíveis pelos botões vermelhos.
        go("new", { data: v });

      },


      mes: (v) => {

        const d =
          new Date(
            S.cal.y,
            S.cal.m +
            Number(v),
            1
          );

        S.cal = {
          y:
            d.getFullYear(),
          m:
            d.getMonth()
        };

        render();
      },


      mesHoje: () => {

        S.cal = {
          y:
            now.getFullYear(),
          m:
            now.getMonth()
        };

        render();
      },


      limpar: () => {

        S.f = {};

        render();
      },


      pw: (v, b) => {

        const i =
          b.parentElement.querySelector(
            "input"
          );

        if (!i) return;

        i.type =
          i.type ===
            "password"
            ? "text"
            : "password";
      },


      /* FOTO DE PERFIL */

      abrirSeletorFoto: () => {

        document
          .querySelector(
            "[data-foto-input]"
          )
          ?.click();

      },


      removerFotoPerfil: () => {

        S.ui.fotoPerfil = "";

        if (S.user) {
          S.user.foto = "";
        }

        S.ui.fotoMsg = null;

        render();
      },


      editar: () => {

        S.ui.edit =
          true;

        render();
      },


      cancelarEd: () => {

        CAMPOS.forEach(([k]) => {

          S.f["p_" + k] =
            S.user?.[k] ?? "";

        });

        S.ui.edit =
          false;

        render();
      },


      salvar: () => {

        S.ui.edit =
          false;

        render();
      },


      cancelarReserva: () => {

        S.ui.modal =
          false;

        render();
      },


      lidas: () => {

        S.notifications.forEach(
          (n) => {
            n.lida = true;
          }
        );

        render();
      }

    };


    /* ================================================================
       CLIQUES
       ================================================================ */

    document.addEventListener(
      "click",
      (e) => {

        const b =
          e.target.closest(
            "[data-a]"
          );

        if (!b) {
          return;
        }

        if (
          b.disabled ||
          b.hasAttribute("disabled")
        ) {
          return;
        }

        const acao =
          b.dataset.a;

        if (
          act[acao] &&
          typeof act[acao] ===
          "function"
        ) {

          act[acao](
            b.dataset.v,
            b
          );

        }

      }
    );


    /* ================================================================
       INPUTS
       ================================================================ */

    document.addEventListener(
      "input",
      (e) => {

        const k =
          e.target.dataset.k;

        if (!k) return;

        S.f[k] =
          e.target.value;

        if (
          e.target.dataset.r
        ) {
          render();
        }

      }
    );


    /* ================================================================
       FOTO DE PERFIL (SELEÇÃO DE ARQUIVO)
       ================================================================ */

    document.addEventListener(
      "change",
      async (e) => {

        const inp = e.target.closest(
          "[data-foto-input]"
        );

        if (!inp) return;

        const file =
          inp.files && inp.files[0];

        if (!file) return;

        if (
          !file.type.startsWith("image/")
        ) {

          S.ui.fotoMsg = [
            "err",
            "Selecione um arquivo de imagem válido."
          ];

          render();
          return;
        }

        try {

          const dataUrl =
            await redimensionarImagem(
              file
            );

          S.ui.fotoPerfil = dataUrl;

          if (S.user) {
            S.user.foto = dataUrl;
          }

          S.ui.fotoMsg = [
            "ok",
            "Foto de perfil atualizada."
          ];

          render();

        } catch (err) {

          console.error(
            "Erro ao processar a foto de perfil:",
            err
          );

          S.ui.fotoMsg = [
            "err",
            "Não foi possível carregar a imagem selecionada."
          ];

          render();
        }

      }
    );


    /* ================================================================
       FORMULÁRIOS
       ================================================================ */

    const forms = {

      login: () => {

        go("home");

      },


      cadastro: () => {

        S.ui.msg =
          S.f.senha !==
            S.f.conf
            ? [
              "err",
              "As senhas não coincidem."
            ]
            : [
              "ok",
              "Cadastro de demonstração: nada foi salvo. A criação da conta virá do Back-End."
            ];

        render();

      },


      nova: () => {

        if (
          !S.f.fotoProfessor
        ) {

          S.ui.msg = [
            "err",
            "É obrigatório tirar uma foto do rosto antes de solicitar a reserva."
          ];

          render();

          return;
        }


        if (!S.ui.sala) {

          S.ui.msg = [
            "err",
            "Selecione uma sala antes de continuar."
          ];

          render();

          return;
        }


        if (
          !S.f.ini ||
          !S.f.fim
        ) {

          S.ui.msg = [
            "err",
            "Informe o horário inicial e final."
          ];

          render();

          return;
        }


        if (
          S.f.fim <=
          S.f.ini
        ) {

          S.ui.msg = [
            "err",
            "O horário final deve ser depois do inicial."
          ];

          render();

          return;
        }


        /*
          BACKEND:

          POST /reservas

          {
            salaId: S.ui.sala.id,
            data: S.f.data,
            ini: S.f.ini,
            fim: S.f.fim,
            turma: S.f.turma,
            fin: S.f.fin,
            pes: S.f.pes,
            obs: S.f.obs,
            fotoProfessor: S.f.fotoProfessor
          }
        */

        S.ui.msg = [
          "ok",
          "Solicitação pronta. A foto do professor foi vinculada à reserva."
        ];

        render();
      },


      senha: () => {

        S.ui.msg =
          S.f.n !==
            S.f.c
            ? [
              "err",
              "As senhas não coincidem."
            ]
            : [
              "ok",
              "Ação de demonstração: a troca real será feita pelo Back-End."
            ];

        render();
      }

    };


    document.addEventListener(
      "submit",
      (e) => {

        const f =
          forms[
          e.target.dataset.form
          ];

        if (f) {

          e.preventDefault();

          f();

        }

      }
    );


    /* ================================================================
       CARGA INICIAL
       ================================================================ */

    async function load() {

      try {

        const [
          user,
          rooms,
          reservations,
          requests,
          notifications
        ] = await Promise.all([
          api.perfil(),
          api.salas(),
          api.reservas(),
          api.solicitacoes(),
          api.notificacoes()
        ]);

        Object.assign(S, {
          user,
          rooms,
          reservations,
          requests,
          notifications
        });

      } catch (err) {

        console.error(
          "Falha ao carregar dados:",
          err
        );

      }

      const fileName =
        window.location.pathname.split("/").pop() || "index.html";

      const pageByFile = {
        "index.html": "login",
        "cadastro.html": "register",
        "home.html": "home",
        "minhas_reservas.html": "reservations",
        "detalhes_reserva.html": "reservation",
        "salas.html": "rooms",
        "detalhes_sala.html": "room",
        "nova_reserva.html": "new",
        "solicitacoes.html": "requests",
        "perfil.html": "profile",
        "notificacoes.html": "notifications"
      };

      S.page = pageByFile[fileName] || "home";

      const params = new URLSearchParams(window.location.search);

      if (params.has("id")) {
        const id = params.get("id");
        S.sel.reservation = find(S.reservations, id);
        S.sel.room = find(S.rooms, id);
      }

      if (params.has("sala")) {
        S.ui.sala = find(S.rooms, params.get("sala"));
        if (S.ui.sala) {
          S.ui.bloco = S.ui.sala.bloco;
        }
      }

      if (params.has("data")) {
        S.f.data = params.get("data");
      }

      render();
    }


    /* ================================================================
       API PÚBLICA
       ================================================================ */

    window.SenaiApp = {

      setData: (d) => {

        Object.assign(
          S,
          d
        );

        render();

      },

      reload: load

    };


    /* ================================================================
       INICIAR
       ================================================================ */

    load();

  