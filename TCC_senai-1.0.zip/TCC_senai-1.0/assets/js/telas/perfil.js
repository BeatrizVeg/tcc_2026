Object.assign(views, {

      /* ================= PERFIL ================= */

      profile: () => {

        const ed = S.ui.edit;
        const tab = S.ui.ptab || "info";

        const tb = (k, l, i) => `
          <button
            type="button"
            data-a="ptab"
            data-v="${k}"
            class="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-sm font-semibold transition ${tab === k
            ? "bg-indigo-100 text-[#1E2A78]"
            : "text-[#6B7280] hover:bg-gray-100"
          }"
          >
            ${ic(i)}
            ${l}
          </button>
        `;

        return pg(`

          <div class="grid gap-6 lg:grid-cols-[280px_1fr]">

            <div class="${CARD} flex h-fit flex-col items-center gap-3 p-5">

              ${avatarEditavel(
          S.user?.nome,
          80,
          S.ui.fotoPerfil || S.user?.foto
        )}

              <p class="font-bold">
                ${esc(
          S.user?.nome ||
          "Usuário"
        )}
              </p>

              <p class="text-xs text-[#6B7280]">
                ${esc(
          S.user?.tipo ||
          "Tipo não informado"
        )}
              </p>

              <div class="flex items-center gap-2">

                ${btn(
          "Trocar foto",
          {
            a: "abrirSeletorFoto",
            i: "camera",
            k: "outline"
          }
        )}

                ${(S.ui.fotoPerfil || S.user?.foto)
          ? btn(
            "Remover",
            {
              a: "removerFotoPerfil",
              k: "ghost"
            }
          )
          : ""
        }

              </div>

              ${S.ui.fotoMsg
          ? `
                    <p class="text-center text-xs ${S.ui.fotoMsg[0] === "err"
            ? "text-rose-700"
            : "text-green-700"
          }">
                      ${esc(S.ui.fotoMsg[1])}
                    </p>
                  `
          : ""
        }

              <div class="w-full space-y-1">

                ${tb(
          "info",
          "Informações pessoais",
          "user"
        )}

                ${tb(
          "senha",
          "Alterar senha",
          "lock"
        )}

              </div>

            </div>


            <div class="${CARD} p-5">

              ${tab === "senha"
            ? senhaForm()
            : `

                    ${ttl(
              "user",
              "Informações pessoais",
              ed
                ? ""
                : btn(
                  "Editar perfil",
                  {
                    a: "editar",
                    i: "pencil",
                    k: "outline"
                  }
                )
            )}

                    <div class="mt-4 grid gap-4 sm:grid-cols-2">

                      ${CAMPOS.map(
              ([k, l]) =>
                input(
                  l,
                  "p_" + k,
                  {
                    req: false,
                    dis: !ed,
                    type:
                      k ===
                        "nascimento"
                        ? "date"
                        : "text"
                  }
                )
            ).join("")}

                    </div>

                    ${ed
              ? `
                          <div class="mt-5 flex justify-end gap-2">

                            ${btn(
                "Cancelar",
                {
                  a: "cancelarEd",
                  k: "ghost"
                }
              )}

                            ${btn(
                "Salvar",
                {
                  a: "salvar"
                }
              )}

                          </div>
                        `
              : ""
            }

                  `
          }

            </div>

          </div>
        `);
      },

});
