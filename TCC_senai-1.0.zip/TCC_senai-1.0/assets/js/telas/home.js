Object.assign(views, {

      /* ================= HOME ================= */

      home: () => {

        const prox = S.reservations
          .filter(
            (r) => r.status !== "Cancelada"
          )
          .slice(0, 3);

        return pg(`

          <div class="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">

            ${stat(
          "clock",
          "Reservas",
          S.reservations.length,
          "cadastradas",
          "reservations"
        )}

            ${stat(
          "clipboard-list",
          "Solicitações",
          S.requests.length,
          "enviadas",
          "requests"
        )}

            ${stat(
          "bell",
          "Notificações",
          S.notifications.filter(
            (n) => !n.lida
          ).length,
          "não lidas",
          "notifications"
        )}

            ${stat(
          "building-2",
          "Salas disponíveis",
          S.rooms.filter(
            (r) => r.disponivel
          ).length,
          "para reservar",
          "rooms"
        )}

          </div>


          <div class="grid gap-6 lg:grid-cols-3">

            <div class="${CARD} p-5 lg:col-span-2">

              ${ttl(
          "calendar-days",
          "Próximas reservas"
        )}

              ${prox.length
            ? `
                    <div class="mt-4 space-y-3">
                      ${prox.map(resCard).join("")}
                    </div>
                  `
            : empty(
              "calendar-days",
              "Nenhuma reserva encontrada",
              "Você ainda não possui reservas cadastradas."
            )
          }

            </div>


            <div class="${CARD} space-y-3 p-5">

              ${ttl("plus", "Acessos rápidos")}

              ${btn("Nova reserva", {
            a: "go",
            v: "new",
            i: "plus",
            c: "w-full"
          })}

              ${btn("Ver salas", {
            a: "go",
            v: "rooms",
            i: "building-2",
            k: "outline",
            c: "w-full"
          })}

              ${btn("Minhas reservas", {
            a: "go",
            v: "reservations",
            i: "clock",
            k: "outline",
            c: "w-full"
          })}

            </div>

          </div>
        `);
      },

});
