Object.assign(views, {

      /* ================= SALAS ================= */

      rooms: () => {

        const t = S.ui.tipo || "Todos";

        const lista = S.rooms.filter(
          (r) =>
            t === "Todos" ||
            r.tipo === t
        );

        return pg(`

          <div class="flex flex-wrap gap-2">

            ${["Todos", ...TIPOS]
            .map(
              (c) => `
                  <button
                    type="button"
                    data-a="tipo"
                    data-v="${esc(c)}"
                    class="rounded-full border border-[#C8102E] px-4 py-1.5 text-sm font-semibold transition ${t === c
                  ? "bg-[#C8102E] text-white"
                  : "text-[#C8102E] hover:bg-red-50"
                }"
                  >
                    ${esc(c)}
                  </button>
                `
            )
            .join("")}

          </div>


          ${lista.length
            ? `
                <div class="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
                  ${lista
              .map(
                (r) =>
                  roomCard(
                    r,
                    "verSala"
                  )
              )
              .join("")}
                </div>
              `
            : `
                <div class="${CARD}">
                  ${empty(
              "building-2",
              "Nenhum espaço cadastrado",
              "Os espaços disponíveis serão exibidos aqui quando forem cadastrados."
            )}
                </div>
              `
          }

        `);
      },

});
