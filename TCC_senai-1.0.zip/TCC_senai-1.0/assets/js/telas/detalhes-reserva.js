Object.assign(views, {

      /* ================= DETALHES RESERVA ================= */

      reservation: () => {

        const r = S.sel.reservation;

        const linhas = r
          ? [
            ["Espaço", r.espaco],
            ["Bloco", r.bloco],
            ["Piso", r.piso],
            [
              "Data",
              new Date(
                r.data + "T00:00:00"
              ).toLocaleDateString(
                "pt-BR",
                {
                  dateStyle: "full"
                }
              )
            ],
            [
              "Horário",
              `${r.inicio} – ${r.fim}`
            ],
            ["Responsável", r.responsavel],
            ["Turma", r.turma],
            ["Finalidade", r.finalidade],
            [
              "Quantidade de pessoas",
              r.pessoas
            ],
            ["Descrição", r.descricao]
          ]
          : [];

        return pg(`

          ${back("reservations")}

          <div class="grid gap-6 lg:grid-cols-[1fr_320px]">

            <div class="${CARD} p-5">

              ${r
            ? `

                    <div class="mb-4 flex items-center justify-between">

                      <h2 class="font-bold text-[#A80D25]">
                        Informações da reserva
                      </h2>

                      ${badge(r.status)}

                    </div>

                    ${r.imagem
              ? `
                          <img
                            src="${esc(r.imagem)}"
                            alt=""
                            class="mb-4 h-48 w-full rounded-xl object-cover"
                          >
                        `
              : ""
            }

                    ${r.fotoProfessor
              ? `
                          <div class="mb-5 flex items-center gap-4 rounded-xl bg-[#F8F9FA] p-4">

                            <img
                              src="${esc(r.fotoProfessor)}"
                              alt="Professor responsável"
                              class="h-20 w-20 rounded-full border-2 border-[#C8102E] object-cover"
                            >

                            <div>

                              <p class="text-xs text-[#6B7280]">
                                Professor responsável
                              </p>

                              <p class="font-bold text-[#1E2A78]">
                                ${esc(
                r.responsavel ||
                "Professor"
              )}
                              </p>

                              <p class="mt-1 text-xs text-[#6B7280]">
                                Foto registrada no momento da reserva.
                              </p>

                            </div>

                          </div>
                        `
              : ""
            }

                    <dl class="grid gap-3 sm:grid-cols-2">

                      ${linhas
              .map(
                ([k, v]) => `
                            <div>

                              <dt class="text-xs text-[#6B7280]">
                                ${k}
                              </dt>

                              <dd class="text-sm font-semibold text-[#1E2A78]">
                                ${esc(v) || "--"}
                              </dd>

                            </div>
                          `
              )
              .join("")}

                    </dl>

                  `
            : empty(
              "calendar-days",
              "Nenhuma reserva selecionada",
              "Selecione uma reserva para visualizar seus detalhes."
            )
          }

            </div>


            <div class="space-y-6">

              <div class="${CARD} space-y-3 p-5">

                <h2 class="font-bold text-[#A80D25]">
                  Ações
                </h2>

                ${btn("Alterar reserva", {
            a: "go",
            v: "new",
            i: "pencil",
            k: "navy",
            c: "w-full",
            dis: !r
          })}

                ${btn("Cancelar reserva", {
            a: "modal",
            v: "1",
            i: "trash-2",
            k: "danger",
            c: "w-full",
            dis: !r
          })}

              </div>


              <div class="${CARD} p-5">

                <h2 class="mb-3 flex items-center gap-2 font-bold text-[#A80D25]">
                  ${ic("clock", "w-[18px] h-[18px]")}
                  Histórico da reserva
                </h2>

                ${timeline(r?.historico)}

              </div>

            </div>

          </div>

        `);
      },

});
