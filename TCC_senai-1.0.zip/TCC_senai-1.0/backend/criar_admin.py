"""Cria (ou atualiza) a conta do administrador no banco de dados.

Uso:
  python criar_admin.py admin@senai.br senha123 [Nome do Admin]

A senha é gravada criptografada (hash), nunca em texto puro.
"""
import sys

from werkzeug.security import generate_password_hash

from db import consultar, executar


def main():
    if len(sys.argv) < 3:
        print("Uso: python criar_admin.py <email> <senha> [nome]")
        sys.exit(1)

    email, senha = sys.argv[1], sys.argv[2]
    nome = sys.argv[3] if len(sys.argv) > 3 else "Administrador"

    existente = consultar("SELECT id FROM usuarios WHERE email = %s", (email,), um=True)
    if existente:
        executar(
            "UPDATE usuarios SET perfil = 'admin', senha_hash = %s, ativo = 1 WHERE id = %s",
            (generate_password_hash(senha), existente["id"]))
        print(f"Conta {email} atualizada como administrador.")
    else:
        executar(
            """INSERT INTO usuarios (nome, email, perfil, cargo, senha_hash)
               VALUES (%s, %s, 'admin', 'Administrador', %s)""",
            (nome, email, generate_password_hash(senha)))
        print(f"Administrador {email} criado com sucesso.")


if __name__ == "__main__":
    main()
