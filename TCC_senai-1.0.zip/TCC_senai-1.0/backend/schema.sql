-- Cria a base de dados
CREATE DATABASE IF NOT EXISTS senai_reservas  -- IF NOT EXIXTS: condição de segurança. 
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE senai_reservas;

-- Tabela de USUARIOS
CREATE TABLE IF NOT EXISTS usuarios (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  nome        VARCHAR(120) NOT NULL,
  email       VARCHAR(160) NOT NULL UNIQUE,
  cpf         VARCHAR(14),
  nascimento  DATE,
  telefone    VARCHAR(20),
  matricula   VARCHAR(30),
  cargo       VARCHAR(60) DEFAULT 'Professor',
  perfil      ENUM('professor','admin') NOT NULL DEFAULT 'professor',
  foto        MEDIUMTEXT,
  ativo       TINYINT(1) NOT NULL DEFAULT 1,
  senha_hash  VARCHAR(255) NOT NULL,
  criado_em   DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- tabela de SALAS
CREATE TABLE IF NOT EXISTS salas (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  nome        VARCHAR(100) NOT NULL,
  numero      VARCHAR(20),
  bloco       ENUM('A','B','C') NOT NULL,
  piso        VARCHAR(20),
  tipo        ENUM('Salas de aula','Laboratórios','Espaços de convivência','Auditório','Outros') NOT NULL,
  capacidade  INT,
  descricao   TEXT,
  imagem      VARCHAR(500),
  disponivel  TINYINT(1) NOT NULL DEFAULT 1
);

-- tabela de SALA_EQUIPAMENTOS
CREATE TABLE IF NOT EXISTS sala_equipamentos (
  id       INT AUTO_INCREMENT PRIMARY KEY,
  sala_id  INT NOT NULL,
  nome     VARCHAR(80) NOT NULL,
  FOREIGN KEY (sala_id) REFERENCES salas(id) ON DELETE CASCADE
);

-- tabela de RESERVAS
CREATE TABLE IF NOT EXISTS reservas (
  id              INT AUTO_INCREMENT PRIMARY KEY,
  usuario_id      INT NOT NULL,
  sala_id         INT NOT NULL,
  data            DATE NOT NULL,
  inicio          TIME NOT NULL,
  fim             TIME NOT NULL,
  turma           VARCHAR(60),
  finalidade      VARCHAR(200),
  pessoas         INT,
  observacoes     TEXT,
  foto_professor  MEDIUMTEXT NOT NULL,
  status          ENUM('Em análise','Aprovada','Confirmada','Recusada','Cancelada')
                  NOT NULL DEFAULT 'Em análise',
  motivo_recusa   TEXT,
  motivo_cancelamento TEXT,
  criada_em       DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id),
  FOREIGN KEY (sala_id) REFERENCES salas(id),
  INDEX idx_sala_data (sala_id, data)
);

-- tabela de NOTIFICACOES
CREATE TABLE IF NOT EXISTS notificacoes (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  usuario_id  INT NOT NULL,
  titulo      VARCHAR(120) NOT NULL,
  mensagem    TEXT,
  categoria   VARCHAR(40) DEFAULT 'sistema',
  lida        TINYINT(1) NOT NULL DEFAULT 0,
  criada_em   DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);

-- tabela de HISTORICO (ações do administrador) 
CREATE TABLE IF NOT EXISTS historico (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  tipo        ENUM('Aprovação','Recusa','Cancelamento','Alteração') NOT NULL,
  descricao   TEXT,
  autor       VARCHAR(120),
  criado_em   DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- tabela de CONFIGURACOES (horários e regras de reserva) -----FAZER----
CREATE TABLE IF NOT EXISTS configuracoes (
  id                    INT AUTO_INCREMENT PRIMARY KEY,
  dias                  VARCHAR(20) DEFAULT '1,2,3,4,5',
  abertura              TIME DEFAULT '07:00',
  fechamento            TIME DEFAULT '22:00',
  duracao_max_horas     INT DEFAULT 4,
  antecedencia_min_horas INT DEFAULT 24,
  antecedencia_max_dias INT DEFAULT 60
);

INSERT INTO configuracoes (id) VALUES (1) ON DUPLICATE KEY UPDATE id = 1;

-- dados das salas  ----ARRUMAR COM DADOS CORRETOS----
INSERT INTO salas (nome, bloco, piso, capacidade, descricao) VALUES
 ('Biblioteca', 'A', 'Superior', 40, 'Espaço para aprender e lazer'),
 ('Auditório', 'A', 'Superior', 150, 'Auditório com som e palco.');

-- Equipamentos das salas acima (o primeiro número é o id da sala:
-- 1 = Sala 101, 2 = Laboratório, 3 = Auditório).    ----- ARRUMAR COM DADOS CORRETOS ------
INSERT INTO sala_equipamentos (sala_id, nome) VALUES
 (1,'Computadores'),(1,'Projetor'),(2,'Tripé'),
 (2,'Computador'),(2,'Projetor'),(2,'Caixa de som'),(2,'Ar condicionado'),(2,'Ventilador');
